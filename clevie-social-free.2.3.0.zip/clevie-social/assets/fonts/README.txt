Fonts bundled with Clevie Social
================================

These are served from this site, not from Google. A visitor's IP address would
otherwise reach Google before the page had drawn, and that needs consent which
a privacy policy does not provide.

The files come from the Fontsource packages, which repackage the Google Fonts
for self-hosting without changing them. Each family keeps its own LICENSE file
in its folder. All of them are under the SIL Open Font License 1.1, which allows
bundling and redistribution.

Only the Latin subset is included, in the weights the theme actually offers, so
that a family costs 60 to 160 KB rather than a megabyte.

Family              Weights                  Licence
------------------  -----------------------  -------
inter               400 500 600 700 800      OFL 1.1
roboto              400 500 700 900          OFL 1.1
open-sans           400 500 600 700 800      OFL 1.1
lato                400 700 900              OFL 1.1
montserrat          400 500 600 700 800      OFL 1.1
poppins             400 500 600 700 800      OFL 1.1
dm-sans             400 500 700              OFL 1.1
merriweather        400 700 900              OFL 1.1
lora                400 500 600 700          OFL 1.1
playfair-display    400 500 600 700 800      OFL 1.1

The following are in the paid edition only:

manrope             400 500 600 700 800      OFL 1.1
rubik               400 500 600 700 800      OFL 1.1
work-sans           400 500 600 700 800      OFL 1.1
ibm-plex-sans       400 500 600 700          OFL 1.1
space-grotesk       400 500 600 700          OFL 1.1
oswald              400 500 600 700          OFL 1.1
bitter              400 500 600 700          OFL 1.1
