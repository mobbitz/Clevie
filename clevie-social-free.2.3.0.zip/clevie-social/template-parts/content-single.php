<?php
/**
 * Single post or page.
 *
 * @package Clevie Social
 */

?>
<?php
$cv_media = is_page() ? '' : clevie_post_media( null, 'single' );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $cv_media ? 'cv-post cv-single cv-post--media' : 'cv-post cv-single' ); ?>>

	<?php if ( 'column' === clevie_vote_style() && ! is_page() ) : ?>
		<div class="cv-votes cv-votes--column" data-post-id="<?php echo absint( get_the_ID() ); ?>" data-score="<?php echo esc_attr( clevie_get_score() ); ?>">
			<span class="cv-votes__arrow cv-vote-up" aria-hidden="true"><?php echo clevie_icon( 'up', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<span class="cv-votes__score"><?php echo esc_html( number_format_i18n( clevie_get_score() ) ); ?></span>
			<span class="cv-votes__arrow cv-vote-down" aria-hidden="true"><?php echo clevie_icon( 'down', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
		</div>
	<?php endif; ?>

	<div class="cv-post__inner">

		<?php clevie_breadcrumbs(); ?>
		<?php if ( ! is_page() ) { clevie_post_meta(); } ?>

		<h1 class="cv-post__title"><?php the_title(); ?></h1>

		<?php if ( 'bar' === clevie_vote_style() && ! is_page() ) : ?>
			<div class="cv-votebar cv-votebar--top"><?php clevie_vote_bar( true ); ?></div>
		<?php endif; ?>

		<?php if ( $cv_media ) : ?>
			<?php $cv_blur = ( ! is_page() && clevie_is_short() && has_post_thumbnail() ) ? get_the_post_thumbnail_url( null, 'large' ) : ''; ?>
			<div class="cv-streammedia<?php echo $cv_blur || clevie_is_short() ? ' cv-streammedia--upright' : ''; ?>"
				<?php echo $cv_blur ? 'style="--cv-blur-src:url(' . esc_url( $cv_blur ) . ');"' : ''; ?>>
				<?php echo $cv_media; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		<?php endif; ?>

		<?php
		// A post with a video shows the player, so the preview image would only
		// be the same picture twice.
		if ( ! $cv_media && ! clevie_post_has_video() && has_post_thumbnail() && get_theme_mod( 'clevie_single_featured', true ) ) :
			?>
			<div class="cv-post__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
		<?php endif; ?>

		<div class="cv-entry">
			<?php
			the_content();

			wp_link_pages( array(
				'before' => '<div class="cv-pagination"><div class="nav-links">',
				'after'  => '</div></div>',
			) );
			?>
		</div>

		<?php if ( ! is_page() ) : ?>
			<div class="cv-postfoot">
				<div class="cv-postfoot__pill">
					<?php
					if ( 'bar' === clevie_vote_style() ) {
						clevie_vote_bar( true );
					}

					/**
					 * Room for views, bookmarks and the like, inside the same pill.
					 */
					do_action( 'clevie_post_footer_actions' );
					?>
				</div>

				<a class="cv-postfoot__author" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
					<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
					<span><?php echo esc_html( clevie_user_prefix() . get_the_author() ); ?></span>
				</a>
				<?php do_action( 'clevie_post_byline_actions', (int) get_the_author_meta( 'ID' ) ); ?>
			</div>
		<?php endif; ?>

		<?php if ( ! is_page() && has_tag() ) : ?>
			<div class="cv-tags"><?php the_tags( '', '', '' ); ?></div>
		<?php endif; ?>

		<?php
		if ( ! is_page() ) {
			clevie_share_links();
			clevie_author_box( 'post' );
		}
		?>


		<?php
		// The discussion belongs to the post, so it sits in the same card.
		if ( ! is_page() && ( comments_open() || get_comments_number() ) ) {
			comments_template();
		}
		?>
	</div>
</article>
