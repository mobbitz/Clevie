<?php
/**
 * Bar directly below the header holding the archive title and its buttons.
 *
 * @package Clevie Social
 */

?>
<?php
/**
 * Room for a banner above the bar, for example the header image of a topic.
 */
do_action( 'clevie_before_archive_bar' );
?>
<div class="cv-archive-bar">
	<div class="cv-archive-bar__inner">
		<?php clevie_breadcrumbs(); ?>

		<div class="cv-archive-bar__row">
			<?php if ( is_search() ) : ?>
				<h1 class="cv-archive-bar__title">
					<?php
					/* translators: %s: search term. */
					printf( esc_html__( 'Results for “%s”', 'clevie-social' ), esc_html( get_search_query() ) );
					?>
				</h1>
			<?php else : ?>
				<h1 class="cv-archive-bar__title"><?php the_archive_title(); ?></h1>
			<?php endif; ?>

			<div class="cv-archive-bar__actions">
				<?php
				/**
				 * Room for buttons beside the name of the topic.
				 */
				do_action( 'clevie_archive_header_actions' );
				?>
			</div>
		</div>

		<?php
		if ( ! is_search() ) {
			the_archive_description( '<div class="cv-archive-bar__description">', '</div>' );
		}
		?>
	</div>
</div>

<?php
ob_start();

/**
 * Room directly under the bar, above the list of posts.
 */
do_action( 'clevie_after_archive_bar' );

$cv_extra = trim( (string) ob_get_clean() );

// Whatever lands here is wrapped in the same grid the content below uses, so a
// plugin does not have to work out how many columns this page has.
if ( $cv_extra ) {
	printf(
		'<div class="cv-barextra %1$s">%2$s</div>',
		esc_attr( clevie_shell_class() ),
		$cv_extra // phpcs:ignore WordPress.Security.EscapeOutput
	);
}
