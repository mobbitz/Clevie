<?php
/**
 * Output when no posts were found.
 *
 * @package Clevie Social
 */

?>
<section class="cv-card">
	<div class="cv-card__body">
		<h2><?php esc_html_e( 'Nothing here yet', 'clevie-social' ); ?></h2>

		<?php if ( is_search() ) : ?>
			<p><?php esc_html_e( 'That search came back empty. Try a different term.', 'clevie-social' ); ?></p>
			<?php get_search_form(); ?>
		<?php elseif ( current_user_can( 'publish_posts' ) ) : ?>
			<p>
				<a href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>"><?php esc_html_e( 'Write the first post', 'clevie-social' ); ?></a>
			</p>
		<?php else : ?>
			<p><?php esc_html_e( 'Check back later or use the search.', 'clevie-social' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</section>
