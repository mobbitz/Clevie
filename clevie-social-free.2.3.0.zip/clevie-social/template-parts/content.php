<?php
/**
 * Post in the feed (card).
 *
 * @package Clevie Social
 */

?>
<?php
$cv_short = clevie_is_short();
$cv_media = clevie_post_media( null, 'feed' );
$cv_class = 'cv-post';

if ( $cv_media ) {
	$cv_class .= ' cv-post--media';
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $cv_class ); ?>>

	<?php if ( 'column' === clevie_vote_style() ) : ?>
		<div class="cv-votes cv-votes--column" data-post-id="<?php echo absint( get_the_ID() ); ?>" data-score="<?php echo esc_attr( clevie_get_score() ); ?>">
			<span class="cv-votes__arrow cv-vote-up" aria-hidden="true"><?php echo clevie_icon( 'up', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<span class="cv-votes__score"><?php echo esc_html( number_format_i18n( clevie_get_score() ) ); ?></span>
			<span class="cv-votes__arrow cv-vote-down" aria-hidden="true"><?php echo clevie_icon( 'down', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
		</div>
	<?php endif; ?>

	<div class="cv-post__inner">
		<?php clevie_post_meta(); ?>

		<h2 class="cv-post__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<?php if ( $cv_media ) : ?>
			<?php $cv_blur = ( $cv_short && has_post_thumbnail() ) ? get_the_post_thumbnail_url( null, 'large' ) : ''; ?>
			<div class="cv-streammedia<?php echo $cv_short ? ' cv-streammedia--upright' : ''; ?>"
				<?php echo $cv_blur ? 'style="--cv-blur-src:url(' . esc_url( $cv_blur ) . ');"' : ''; ?>>
				<?php echo $cv_media; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		<?php endif; ?>

		<?php if ( ! $cv_media && ! has_post_thumbnail() && ( clevie_is_short() || clevie_post_has_video() ) && get_theme_mod( 'clevie_show_thumbs', true ) ) : ?>
			<a class="cv-post__thumb cv-post__thumb--placeholder" href="<?php the_permalink(); ?>" aria-label="<?php esc_attr_e( 'Watch the clip', 'clevie-social' ); ?>">
				<span class="cv-play" aria-hidden="true">
					<svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
				</span>
			</a>
		<?php endif; ?>

		<?php if ( ! $cv_media && has_post_thumbnail() && get_theme_mod( 'clevie_show_thumbs', true ) ) : ?>
			<a class="cv-post__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
				<?php the_post_thumbnail( 'clevie-full', array( 'loading' => 'lazy' ) ); ?>
			</a>
		<?php endif; ?>

		<div class="cv-post__excerpt"><?php the_excerpt(); ?></div>

		<div class="cv-actions">
			<?php if ( 'bar' === clevie_vote_style() ) { clevie_vote_bar(); } ?>
			<?php if ( get_theme_mod( 'clevie_meta_comments', true ) ) : ?>
				<a href="<?php echo esc_url( get_comments_link() ); ?>">
					<?php echo clevie_icon( 'comment', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php
					printf(
						/* translators: %s: number of comments. */
						esc_html( _n( '%s comment', '%s comments', (int) get_comments_number(), 'clevie-social' ) ),
						esc_html( number_format_i18n( get_comments_number() ) )
					);
					?>
				</a>
			<?php endif; ?>
			<?php
			/**
			 * Room for buttons of a plugin in the action row of a card.
			 */
			do_action( 'clevie_post_actions' );
			?>
			<a href="<?php the_permalink(); ?>">
				<?php echo clevie_icon( 'share', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php
				$cv_more = get_theme_mod( 'clevie_read_more_text', '' );
				echo esc_html( $cv_more ? $cv_more : __( 'Read more', 'clevie-social' ) );
				?>
			</a>
		</div>
	</div>
</article>
