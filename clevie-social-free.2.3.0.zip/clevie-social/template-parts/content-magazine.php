<?php
/**
 * Single tile in the magazine.
 *
 * @package Clevie Social
 */

$cv_settings = get_query_var( 'clevie_magazine' );

if ( ! is_array( $cv_settings ) ) {
	$cv_settings = clevie_magazine_defaults();
}

// Grids need every tile the same shape, a list and masonry do not.
$cv_size = in_array( $cv_settings['style'], array( 'masonry', 'list' ), true ) ? 'clevie-full' : 'clevie-card';

// Upright videos only take over the layout in the list style. Grid and masonry
// keep their tiles and show the video once the post is opened.
$cv_media = ( 'list' === $cv_settings['style'] ) ? clevie_post_media( null, 'feed' ) : '';
$cv_class = 'cv-mag__item cv-card';

if ( $cv_media ) {
	$cv_class .= ' cv-mag__item--media';
}
?>
<article id="mag-post-<?php the_ID(); ?>" <?php post_class( $cv_class ); ?>>

	<?php if ( $cv_media ) : ?>
		<div class="cv-streammedia<?php echo clevie_is_short() ? ' cv-streammedia--upright' : ''; ?>"><?php echo $cv_media; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
	<?php elseif ( 'none' !== $cv_settings['image'] && has_post_thumbnail() ) : ?>
		<a class="cv-mag__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( $cv_size, array( 'loading' => 'lazy' ) ); ?>
		</a>
	<?php elseif ( 'none' !== $cv_settings['image'] && ( clevie_is_short() || clevie_post_has_video() ) ) : ?>
		<a class="cv-mag__thumb cv-mag__thumb--placeholder" href="<?php the_permalink(); ?>" aria-label="<?php esc_attr_e( 'Watch the clip', 'clevie-social' ); ?>">
			<span class="cv-play" aria-hidden="true">
				<svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
			</span>
		</a>
	<?php endif; ?>

	<div class="cv-mag__body">
		<?php if ( ! empty( $cv_settings['show_meta'] ) ) : ?>
			<?php
			$cv_cats = get_the_category();
			?>
			<div class="cv-mag__meta">
				<?php if ( ! empty( $cv_cats ) ) : ?>
					<a class="cv-mag__cat" href="<?php echo esc_url( get_category_link( $cv_cats[0]->term_id ) ); ?>"><?php echo esc_html( $cv_cats[0]->name ); ?></a>
				<?php endif; ?>
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			</div>
		<?php endif; ?>

		<h2 class="cv-mag__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<?php if ( ! empty( $cv_settings['show_excerpt'] ) ) : ?>
			<div class="cv-mag__excerpt"><?php the_excerpt(); ?></div>
		<?php endif; ?>

		<div class="cv-mag__actions"><?php do_action( 'clevie_post_actions' ); ?></div>

		<div class="cv-mag__footer">
			<span><?php echo esc_html( clevie_user_prefix() . get_the_author() ); ?></span>
			<span>&middot;</span>
			<span>
				<?php
				printf(
					/* translators: %s: number of comments. */
					esc_html( _n( '%s comment', '%s comments', (int) get_comments_number(), 'clevie-social' ) ),
					esc_html( number_format_i18n( get_comments_number() ) )
				);
				?>
			</span>
		</div>
	</div>
</article>
