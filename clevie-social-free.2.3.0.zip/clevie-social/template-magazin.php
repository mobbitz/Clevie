<?php
/**
 * Template Name: Magazine
 *
 * Shows posts in the chosen magazine style. Layout, columns, image position and the
 * right sidebar come from the Customizer and can be overridden per page.
 *
 * @package Clevie Social
 */

$cv_settings = clevie_magazine_settings( get_queried_object_id() );

if ( 'hide' === $cv_settings['sidebar'] ) {
	$GLOBALS['clevie_hide_right_sidebar'] = true;
}

get_header();

$cv_paged = max( 1, get_query_var( 'paged' ), get_query_var( 'page' ) );

$cv_args = array(
	'post_type'           => 'post',
	'posts_per_page'      => $cv_settings['per_page'],
	'paged'               => $cv_paged,
	'ignore_sticky_posts' => true,
);

if ( $cv_settings['category'] ) {
	$cv_args['cat'] = $cv_settings['category'];
}

$cv_query = new WP_Query( apply_filters( 'clevie_magazine_query_args', $cv_args, $cv_settings ) );

while ( have_posts() ) :
	the_post();

	if ( get_the_title() || trim( get_the_content() ) ) :
		?>
		<header class="cv-mag-intro cv-card">
			<div class="cv-card__body">
				<h1><?php the_title(); ?></h1>
				<div class="cv-entry"><?php the_content(); ?></div>
			</div>
		</header>
		<?php
	endif;
endwhile;

if ( $cv_query->have_posts() ) :
	?>
	<div class="<?php echo esc_attr( clevie_magazine_classes( $cv_settings ) ); ?>" style="--cv-mag-cols:<?php echo absint( $cv_settings['columns'] ); ?>;">
		<?php
		while ( $cv_query->have_posts() ) :
			$cv_query->the_post();
			set_query_var( 'clevie_magazine', $cv_settings );
			get_template_part( 'template-parts/content', 'magazine' );
		endwhile;
		?>
	</div>

	<?php
	echo '<nav class="cv-pagination"><div class="nav-links">';
	echo wp_kses_post( paginate_links( array(
		'total'     => $cv_query->max_num_pages,
		'current'   => $cv_paged,
		'mid_size'  => 1,
		'prev_text' => __( 'Previous', 'clevie-social' ),
		'next_text' => __( 'Next', 'clevie-social' ),
		'type'      => 'plain',
	) ) );
	echo '</div></nav>';

	wp_reset_postdata();
else :
	get_template_part( 'template-parts/content', 'none' );
endif;

get_footer();
