<?php
/**
 * Main template: post list as a card feed or in the magazine layout.
 *
 * @package Clevie Social
 */

$cv_settings = clevie_view_settings();
$cv_magazine = ( 'magazine' === $cv_settings['mode'] );

if ( $cv_magazine && 'hide' === $cv_settings['sidebar'] ) {
	$GLOBALS['clevie_hide_right_sidebar'] = true;
}

get_header();
?>

<?php if ( $cv_magazine ) : ?>

	<?php if ( have_posts() ) : ?>
		<div class="<?php echo esc_attr( clevie_magazine_classes( $cv_settings ) ); ?>" style="--cv-mag-cols:<?php echo absint( $cv_settings['columns'] ); ?>;">
			<?php
			while ( have_posts() ) :
				the_post();
				set_query_var( 'clevie_magazine', $cv_settings );
				get_template_part( 'template-parts/content', 'magazine' );
			endwhile;
			?>
		</div>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content', 'none' ); ?>
	<?php endif; ?>

<?php else : ?>

	<?php
	/**
	 * Room for a notice above the feed.
	 */
	do_action( 'clevie_before_feed' );
	?>

	<div class="cv-toolbar">
		<strong><?php esc_html_e( 'New', 'clevie-social' ); ?></strong>
		<span>&middot;</span>
		<span>
			<?php
			global $wp_query;
			printf(
				/* translators: %s: number of posts. */
				esc_html( _n( '%s post', '%s posts', (int) $wp_query->found_posts, 'clevie-social' ) ),
				esc_html( number_format_i18n( $wp_query->found_posts ) )
			);
			?>
		</span>
	</div>

	<div class="cv-feed cv-feed--<?php echo esc_attr( get_theme_mod( 'clevie_feed_style', 'card' ) ); ?>">
		<?php
		if ( have_posts() ) :
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content' );
			endwhile;
		else :
			get_template_part( 'template-parts/content', 'none' );
		endif;
		?>
	</div>

<?php endif; ?>

<?php
if ( function_exists( 'clevie_loadmore_active' ) && clevie_loadmore_active() ) {
	clevie_loadmore_button();
} else {
	the_posts_pagination( array(
		'class'     => 'cv-pagination',
		'mid_size'  => 1,
		'prev_text' => __( 'Previous', 'clevie-social' ),
		'next_text' => __( 'Next', 'clevie-social' ),
	) );
}

get_footer();
