<?php
/**
 * Comments area.
 *
 * @package Clevie Social
 */

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="cv-comments">

	<?php if ( have_comments() ) : ?>
		<h2 class="cv-comments__title">
			<?php
			printf(
				/* translators: %s: number of comments. */
				esc_html( _n( '%s comment', '%s comments', (int) get_comments_number(), 'clevie-social' ) ),
				esc_html( number_format_i18n( get_comments_number() ) )
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'callback'   => 'clevie_comment',
				'style'      => 'ol',
				'avatar_size' => 24,
			) );
			?>
		</ol>

		<?php
		the_comments_pagination( array(
			'class'     => 'cv-pagination',
			'prev_text' => __( 'Previous', 'clevie-social' ),
			'next_text' => __( 'Next', 'clevie-social' ),
		) );
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'clevie-social' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		// Whoever is not signed in cannot comment anyway, and the account is one
		// click away. The default lines only take up room.
		'logged_in_as'        => '',
		'comment_notes_before' => '',
		'comment_notes_after' => '',
		'title_reply'         => __( 'What do you think?', 'clevie-social' ),
		'title_reply_to'      => __( 'Reply to %s', 'clevie-social' ),
		'cancel_reply_link'   => __( 'Cancel', 'clevie-social' ),
		'label_submit'        => __( 'Post comment', 'clevie-social' ),
		'comment_field'       => sprintf(
			'<p class="comment-form-comment"><label for="comment" class="screen-reader-text">%1$s</label><textarea id="comment" name="comment" rows="5" placeholder="%2$s" required></textarea></p>',
			esc_html__( 'Comment', 'clevie-social' ),
			esc_attr__( 'Write a comment …', 'clevie-social' )
		),
	) );
	?>
</div>
