/**
 * Clevie Social: fetching the next posts in place.
 *
 * The button is the whole interface. Nothing loads until it is pressed, and
 * when there is nothing left the button says so and goes away rather than
 * sitting there doing nothing.
 *
 * Newly fetched posts are announced to screen readers, because otherwise the
 * page simply grows in silence and somebody not looking at it has no idea
 * anything happened.
 */
(function () {
	'use strict';

	var config = window.clevieLoadMore || {};

	function start() {
		var box = document.querySelector('.cv-loadmore');
		var feed = document.querySelector('.cv-feed');

		if (!box || !feed || !config.url) {
			return;
		}

		var button = box.querySelector('.cv-loadmore__button');
		var page = parseInt(box.getAttribute('data-page'), 10) || 1;
		var busy = false;

		// Where the count of what arrived is announced.
		var status = document.createElement('p');
		status.className = 'cv-loadmore__status screen-reader-text';
		status.setAttribute('aria-live', 'polite');
		box.appendChild(status);

		function fail(message) {
			busy = false;
			button.disabled = false;
			button.textContent = config.i18n ? config.i18n.more : 'Load more';
			status.textContent = message;
		}

		button.addEventListener('click', function () {
			if (busy) {
				return;
			}

			busy = true;
			button.disabled = true;
			button.textContent = config.i18n ? config.i18n.loading : 'Loading…';

			var body = new FormData();
			body.append('action', 'clevie_loadmore');
			body.append('nonce', config.nonce);
			body.append('page', page + 1);
			body.append('query', config.query || '{}');

			fetch(config.url, {
				method: 'POST',
				body: body,
				credentials: 'same-origin'
			})
				.then(function (response) {
					return response.json();
				})
				.then(function (answer) {
					if (!answer || !answer.success || !answer.data) {
						fail(config.i18n ? config.i18n.failed : '');
						return;
					}

					var html = answer.data.html || '';

					if (html) {
						// Built off-document and moved in one piece, so the
						// browser lays the page out once rather than per post.
						var holder = document.createElement('div');
						holder.innerHTML = html;

						var added = holder.children.length;
						var fragment = document.createDocumentFragment();

						while (holder.firstChild) {
							fragment.appendChild(holder.firstChild);
						}

						feed.appendChild(fragment);
						page += 1;

						status.textContent = added + '';
					}

					if (answer.data.done || !html) {
						box.parentNode.removeChild(box);
						return;
					}

					busy = false;
					button.disabled = false;
					button.textContent = config.i18n ? config.i18n.more : 'Load more';
				})
				.catch(function () {
					fail(config.i18n ? config.i18n.failed : '');
				});
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', start);
	} else {
		start();
	}
})();
