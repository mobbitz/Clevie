/**
 * Clevie Social front-end behaviour.
 */
(function () {
	'use strict';

	var root = document.documentElement;
	var settings = window.clevieSettings || { defaultScheme: 'light' };

	function store(value) {
		try {
			localStorage.setItem('clevie-scheme', value);
		} catch (e) {}
	}

	function stored() {
		try {
			return localStorage.getItem('clevie-scheme');
		} catch (e) {
			return null;
		}
	}

	function current() {
		return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
	}

	function apply(scheme) {
		root.setAttribute('data-theme', scheme);
		toggles.forEach(function (btn) {
			btn.setAttribute('aria-pressed', scheme === 'dark' ? 'true' : 'false');
		});
	}

	/* --- Light and dark ----------------------------------- */
	var toggles = Array.prototype.slice.call(document.querySelectorAll('.cv-theme-toggle'));

	apply(current());

	toggles.forEach(function (btn) {
		btn.addEventListener('click', function () {
			var next = current() === 'dark' ? 'light' : 'dark';
			apply(next);
			store(next);
		});
	});

	// Follow the system only while the visitor has not chosen manually.
	if (settings.defaultScheme === 'auto' && window.matchMedia) {
		var mq = window.matchMedia('(prefers-color-scheme: dark)');
		var listener = function (event) {
			if (!stored()) {
				apply(event.matches ? 'dark' : 'light');
			}
		};
		if (mq.addEventListener) {
			mq.addEventListener('change', listener);
		} else if (mq.addListener) {
			mq.addListener(listener);
		}
	}

	/* --- Menu drawer on small screens --------------------- */
	var menuButton = document.querySelector('.cv-menu-toggle');
	var drawer = document.getElementById('cv-left');
	var overlay = document.querySelector('.cv-overlay');

	function closeDrawer() {
		if (!drawer) {
			return;
		}
		drawer.classList.remove('is-open');
		document.body.classList.remove('cv-menu-open');
		if (overlay) {
			overlay.classList.remove('is-open');
			overlay.hidden = true;
		}
		if (menuButton) {
			menuButton.setAttribute('aria-expanded', 'false');
			menuButton.setAttribute('aria-label', menuButton.dataset.labelOpen || 'Open the menu');
		}
	}

	if (menuButton && drawer) {
		menuButton.dataset.labelOpen = menuButton.getAttribute('aria-label');

		menuButton.addEventListener('click', function () {
			var isOpen = drawer.classList.toggle('is-open');
			menuButton.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
			document.body.classList.toggle('cv-menu-open', isOpen);
			if (overlay) {
				overlay.hidden = !isOpen;
				// Next frame so the fade-in is visible.
				window.requestAnimationFrame(function () {
					overlay.classList.toggle('is-open', isOpen);
				});
			}
		});

		if (overlay) {
			overlay.addEventListener('click', closeDrawer);
		}

		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') {
				closeDrawer();
			}
		});

		// A tap on a link closes the panel again.
		drawer.addEventListener('click', function (event) {
			var link = event.target.closest('a');
			if (link && drawer.classList.contains('is-open')) {
				closeDrawer();
			}
		});

		// Back on a wide screen the panel must not stay half open.
		window.addEventListener('resize', function () {
			if (window.innerWidth > 860) {
				closeDrawer();
			}
		});
	}

	/* --- Collapse sections in the left sidebar ------------ */
	if (document.body.classList.contains('cv-leftbar-fixed') && drawer) {
		Array.prototype.forEach.call(
			drawer.querySelectorAll('.cv-widget > .cv-card__head'),
			function (head) {
				var section = head.parentNode;
				var key = 'clevie-section-' + (section.id || head.textContent.trim());

				head.setAttribute('role', 'button');
				head.setAttribute('tabindex', '0');

				var collapsed = null;
				try {
					collapsed = localStorage.getItem(key);
				} catch (e) {}

				if (collapsed === '1') {
					section.classList.add('is-collapsed');
				}
				head.setAttribute('aria-expanded', collapsed === '1' ? 'false' : 'true');

				var toggle = function () {
					var isCollapsed = section.classList.toggle('is-collapsed');
					head.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
					try {
						localStorage.setItem(key, isCollapsed ? '1' : '0');
					} catch (e) {}
				};

				head.addEventListener('click', toggle);
				head.addEventListener('keydown', function (event) {
					if (event.key === 'Enter' || event.key === ' ') {
						event.preventDefault();
						toggle();
					}
				});
			}
		);
	}

	/* --- Long posts in the stream fold open ---------------- */
	document.addEventListener('click', function (event) {
		var button = event.target.closest('.cv-fold__button');

		if (!button) {
			return;
		}

		var fold = button.closest('.cv-fold');

		if (!fold) {
			return;
		}

		if (fold.classList.contains('is-open')) {
			fold.classList.remove('is-open');

			// Closing from the middle of a long text would leave the reader
			// somewhere below the post, so bring its top back into view.
			if (fold.getBoundingClientRect().top < 0) {
				fold.scrollIntoView({ block: 'start', behavior: 'smooth' });
			}
		} else {
			fold.classList.add('is-open');
		}
	});

	// A post short enough to fit does not need the button at all.
	var tidyFolds = function (scope) {
		Array.prototype.forEach.call((scope || document).querySelectorAll('[data-fold]'), function (fold) {
			var body = fold.querySelector('.cv-fold__body');
			var button = fold.querySelector('.cv-fold__button');

			if (body && button && body.scrollHeight <= body.clientHeight + 20) {
				fold.classList.add('is-open');
				button.hidden = true;
			}
		});
	};

	tidyFolds();
	window.clevieTidyFolds = tidyFolds;

	/* --- Back to top -------------------------------------- */
	var topButton = document.querySelector('.cv-backtotop');

	if (topButton) {
		var onScroll = function () {
			topButton.classList.toggle('is-visible', window.scrollY > 600);
		};
		window.addEventListener('scroll', onScroll, { passive: true });
		onScroll();

		topButton.addEventListener('click', function () {
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	}
})();
