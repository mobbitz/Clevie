/**
 * Live preview in the Customizer: colors and sizes without a reload.
 */
(function ($) {
	'use strict';

	var maps = window.cleviePreview || { light: {}, dark: {}, layout: {} };
	var values = { light: {}, dark: {}, layout: {} };

	function styleTag() {
		var tag = document.getElementById('clevie-live-css');
		if (!tag) {
			tag = document.createElement('style');
			tag.id = 'clevie-live-css';
			document.head.appendChild(tag);
		}
		return tag;
	}

	function render() {
		var lightCss = '';
		var darkCss = '';

		Object.keys(values.light).forEach(function (id) {
			lightCss += maps.light[id] + ':' + values.light[id] + ';';
		});
		Object.keys(values.layout).forEach(function (id) {
			lightCss += maps.layout[id] + ':' + parseInt(values.layout[id], 10) + 'px;';
		});
		Object.keys(values.dark).forEach(function (id) {
			darkCss += maps.dark[id] + ':' + values.dark[id] + ';';
		});

		styleTag().textContent =
			':root{' + lightCss + '}html[data-theme="dark"]{' + darkCss + '}';
	}

	function bind(group) {
		Object.keys(maps[group]).forEach(function (id) {
			wp.customize(id, function (setting) {
				setting.bind(function (value) {
					values[group][id] = value;
					render();
				});
			});
		});
	}

	bind('light');
	bind('dark');
	bind('layout');

	var simple = {
		clevie_font_size: ['--cv-font-size', 'px'],
		clevie_line_height: ['--cv-line-height', ''],
		clevie_heading_spacing: ['--cv-heading-spacing', 'px']
	};

	Object.keys(simple).forEach(function (id) {
		wp.customize(id, function (setting) {
			setting.bind(function (value) {
				document.documentElement.style.setProperty(simple[id][0], value + simple[id][1]);
			});
		});
	});

	wp.customize('blogname', function (value) {
		value.bind(function (to) {
			$('.cv-brand__name').text(to);
		});
	});
})(jQuery);
