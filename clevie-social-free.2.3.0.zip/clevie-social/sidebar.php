<?php
/**
 * Right sidebar.
 *
 * @package Clevie Social
 */

$cv_author_card = ( is_singular( 'post' ) && 'sidebar' === get_theme_mod( 'clevie_author_box_position', 'none' ) && get_theme_mod( 'clevie_single_author_box', true ) );

if ( ! clevie_right_sidebar_active() && ! $cv_author_card ) {
	return;
}
?>
<aside id="cv-right" class="cv-col cv-col--right cv-widgets cv-widgets--right">
	<?php if ( $cv_author_card ) : ?>
		<section class="cv-widget cv-card cv-author-card">
			<h2 class="cv-card__head"><?php esc_html_e( 'Written by', 'clevie-social' ); ?></h2>
			<?php clevie_author_box( 'sidebar' ); ?>
		</section>
	<?php endif; ?>

	<?php dynamic_sidebar( 'sidebar-right' ); ?>
</aside>
