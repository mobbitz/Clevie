<?php
/**
 * Header.
 *
 * @package Clevie Social
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#cv-content"><?php esc_html_e( 'Skip to content', 'clevie-social' ); ?></a>

<header class="<?php echo esc_attr( get_theme_mod( 'clevie_sticky_header', true ) ? 'cv-topbar' : 'cv-topbar cv-topbar--static' ); ?>">

	<button class="cv-btn cv-btn--ghost cv-menu-toggle" aria-expanded="false" aria-controls="cv-left" aria-label="<?php esc_attr_e( 'Open the menu', 'clevie-social' ); ?>">
		<?php echo clevie_icon( 'menu', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</button>

	<div class="cv-brand">
		<?php if ( has_custom_logo() ) : ?>
			<?php the_custom_logo(); ?>
		<?php else : ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<span class="cv-brand__mark"><?php echo clevie_icon( 'up', 28 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span class="cv-brand__name"><?php bloginfo( 'name' ); ?></span>
			</a>
		<?php endif; ?>
	</div>

	<?php if ( get_theme_mod( 'clevie_show_search', true ) ) : ?>
		<div class="cv-topbar__search">
			<?php get_search_form(); ?>
		</div>
	<?php endif; ?>

	<div class="cv-topbar__actions">
		<?php
		/**
		 * Room in the header for buttons of a plugin, for example a bell.
		 */
		do_action( 'clevie_header_actions' );
		?>

		<?php
		$button_text = get_theme_mod( 'clevie_button_text', '' );
		$button_url  = get_theme_mod( 'clevie_button_url', '' );
		if ( $button_text ) :
			?>
			<a class="cv-btn" href="<?php echo esc_url( $button_url ? $button_url : home_url( '/' ) ); ?>"><?php echo esc_html( $button_text ); ?></a>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'clevie_show_toggle', true ) ) : ?>
			<button class="cv-btn cv-btn--ghost cv-theme-toggle" aria-label="<?php esc_attr_e( 'Switch between light and dark mode', 'clevie-social' ); ?>" aria-pressed="false">
				<?php
				echo clevie_icon( 'moon', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput
				echo clevie_icon( 'sun', 20 );  // phpcs:ignore WordPress.Security.EscapeOutput
				?>
			</button>
		<?php endif; ?>
	</div>

	<?php if ( is_singular( 'post' ) && get_theme_mod( 'clevie_reading_progress', false ) ) : ?>
		<div class="cv-progress"><span class="cv-progress__bar"></span></div>
	<?php endif; ?>
</header>

<?php
if ( is_archive() || is_search() ) {
	get_template_part( 'template-parts/archive-bar' );
}
?>

<div class="<?php echo esc_attr( clevie_shell_class() ); ?>">

	<?php if ( clevie_left_column_active() ) : ?>
		<?php get_sidebar( 'left' ); ?>
		<div class="cv-overlay" hidden></div>
	<?php endif; ?>

	<main id="cv-content" class="cv-col cv-col--main">
