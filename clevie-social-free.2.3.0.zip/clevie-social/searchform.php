<?php
/**
 * Search form.
 *
 * @package Clevie Social
 */

$cv_id = 'cv-search-' . wp_rand();
?>
<form role="search" method="get" class="cv-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $cv_id ); ?>"><?php esc_html_e( 'Search', 'clevie-social' ); ?></label>
	<span class="cv-search__icon"><?php echo clevie_icon( 'search', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
	<input type="search" id="<?php echo esc_attr( $cv_id ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr( get_theme_mod( 'clevie_search_placeholder', __( 'Search', 'clevie-social' ) ) ); ?>">
	<button type="submit"><?php esc_html_e( 'Go', 'clevie-social' ); ?></button>
</form>
