<?php
/**
 * WooCommerce support and block editor integration.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Declare WooCommerce support.
 */
function clevie_woocommerce_setup() {
	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width' => 400,
		'single_image_width'    => 800,
		'product_grid'          => array(
			'default_columns' => 3,
			'min_columns'     => 2,
			'max_columns'     => 5,
		),
	) );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'clevie_woocommerce_setup' );

/**
 * Products per row from the Customizer.
 *
 * @return int
 */
function clevie_wc_columns() {
	return (int) get_theme_mod( 'clevie_wc_columns', 3 );
}
add_filter( 'loop_shop_columns', 'clevie_wc_columns', 20 );

/**
 * Products per page from the Customizer.
 *
 * @return int
 */
function clevie_wc_per_page() {
	return (int) get_theme_mod( 'clevie_wc_per_page', 12 );
}
add_filter( 'loop_shop_per_page', 'clevie_wc_per_page', 20 );

/**
 * Shop controls in the Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function clevie_woocommerce_customize( $wp_customize ) {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$wp_customize->add_section( 'clevie_shop', array(
		'title'       => __( 'Shop', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'Only shown while WooCommerce is active. Everything else about the shop is set in WooCommerce itself.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_wc_columns', array(
		'default'           => 3,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_wc_columns', array(
		'label'       => __( 'Products per row', 'clevie-social' ),
		'section'     => 'clevie_shop',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 2, 'max' => 5 ),
	) );

	$wp_customize->add_setting( 'clevie_wc_per_page', array(
		'default'           => 12,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_wc_per_page', array(
		'label'       => __( 'Products per page', 'clevie-social' ),
		'section'     => 'clevie_shop',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 3, 'max' => 60 ),
	) );

	$wp_customize->add_setting( 'clevie_wc_sidebar', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_wc_sidebar', array(
		'label'   => __( 'Show the right sidebar in the shop', 'clevie-social' ),
		'section' => 'clevie_shop',
		'type'    => 'checkbox',
	) );
}
add_action( 'customize_register', 'clevie_woocommerce_customize', 16 );

/**
 * Hide the sidebar in the shop when switched off.
 *
 * @param bool $active Current state.
 * @return bool
 */
function clevie_wc_sidebar( $active ) {
	if ( function_exists( 'is_woocommerce' ) && is_woocommerce() && ! get_theme_mod( 'clevie_wc_sidebar', true ) ) {
		return false;
	}

	return $active;
}
add_filter( 'clevie_right_sidebar_active', 'clevie_wc_sidebar' );

/**
 * Product columns as a CSS variable.
 *
 * @param string $css Existing CSS.
 * @return string
 */
function clevie_wc_css( $css ) {
	return $css . ':root{--cv-wc-cols:' . absint( get_theme_mod( 'clevie_wc_columns', 3 ) ) . ';}';
}
add_filter( 'clevie_inline_css', 'clevie_wc_css' );

/* =========================================================
 * Block editor
 * ========================================================= */

/**
 * Give the editor the same palette and sizes as the front end.
 */
function clevie_editor_support() {
	$colors = array(
		'accent'  => array( __( 'Accent', 'clevie-social' ), get_theme_mod( 'clevie_light_accent', '#ff4500' ) ),
		'button'  => array( __( 'Button', 'clevie-social' ), get_theme_mod( 'clevie_light_blue', '#0079d3' ) ),
		'text'    => array( __( 'Text', 'clevie-social' ), get_theme_mod( 'clevie_light_text', '#1c1c1c' ) ),
		'muted'   => array( __( 'Secondary text', 'clevie-social' ), get_theme_mod( 'clevie_light_muted', '#7c7c7c' ) ),
		'surface' => array( __( 'Card', 'clevie-social' ), get_theme_mod( 'clevie_light_surface', '#ffffff' ) ),
		'page'    => array( __( 'Page background', 'clevie-social' ), get_theme_mod( 'clevie_light_bg', '#dae0e6' ) ),
	);

	$palette = array();
	foreach ( $colors as $slug => $data ) {
		$palette[] = array(
			'name'  => $data[0],
			'slug'  => 'clevie-' . $slug,
			'color' => $data[1],
		);
	}

	add_theme_support( 'editor-color-palette', $palette );

	add_theme_support( 'editor-font-sizes', array(
		array( 'name' => __( 'Small', 'clevie-social' ), 'slug' => 'small', 'size' => 13 ),
		array( 'name' => __( 'Normal', 'clevie-social' ), 'slug' => 'normal', 'size' => 15 ),
		array( 'name' => __( 'Large', 'clevie-social' ), 'slug' => 'large', 'size' => 20 ),
		array( 'name' => __( 'Huge', 'clevie-social' ), 'slug' => 'huge', 'size' => 28 ),
	) );

	add_editor_style( 'assets/editor-style.css' );
}
add_action( 'after_setup_theme', 'clevie_editor_support', 11 );
