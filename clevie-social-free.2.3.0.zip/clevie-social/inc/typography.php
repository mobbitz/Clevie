<?php
/**
 * Typography: font families, sizes and weights.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Available font families: slug => label, CSS stack, Google family (or false).
 *
 * @return array
 */
function clevie_fonts() {
	$system = '-apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans", "Helvetica Neue", Arial, sans-serif';

	// slug => label, CSS stack, directory under assets/fonts, weights, paid.
	// The two system entries carry no files: they are whatever the visitor's
	// device already has, which is why they load fastest.
	$fonts = array(
		'system'   => array( __( 'System font (fastest)', 'clevie-social' ), $system, '', array(), false ),
		'georgia'  => array( __( 'Georgia (system serif)', 'clevie-social' ), 'Georgia, "Times New Roman", serif', '', array(), false ),

		'inter'    => array( 'Inter', '"Inter", ' . $system, 'inter', array( 400, 500, 600, 700, 800 ), false ),
		'roboto'   => array( 'Roboto', '"Roboto", ' . $system, 'roboto', array( 400, 500, 700, 900 ), false ),
		'opensans' => array( 'Open Sans', '"Open Sans", ' . $system, 'open-sans', array( 400, 500, 600, 700, 800 ), false ),
		'lato'     => array( 'Lato', '"Lato", ' . $system, 'lato', array( 400, 700, 900 ), false ),
		'montser'  => array( 'Montserrat', '"Montserrat", ' . $system, 'montserrat', array( 400, 500, 600, 700, 800 ), false ),
		'poppins'  => array( 'Poppins', '"Poppins", ' . $system, 'poppins', array( 400, 500, 600, 700, 800 ), false ),
		'dmsans'   => array( 'DM Sans', '"DM Sans", ' . $system, 'dm-sans', array( 400, 500, 700 ), false ),
		'merriw'   => array( 'Merriweather', '"Merriweather", Georgia, serif', 'merriweather', array( 400, 700, 900 ), false ),
		'lora'     => array( 'Lora', '"Lora", Georgia, serif', 'lora', array( 400, 500, 600, 700 ), false ),
		'playfair' => array( 'Playfair Display', '"Playfair Display", Georgia, serif', 'playfair-display', array( 400, 500, 600, 700, 800 ), false ),

		'manrope'  => array( 'Manrope', '"Manrope", ' . $system, 'manrope', array( 400, 500, 600, 700, 800 ), true ),
		'rubik'    => array( 'Rubik', '"Rubik", ' . $system, 'rubik', array( 400, 500, 600, 700, 800 ), true ),
		'workzans' => array( 'Work Sans', '"Work Sans", ' . $system, 'work-sans', array( 400, 500, 600, 700, 800 ), true ),
		'ibmplex'  => array( 'IBM Plex Sans', '"IBM Plex Sans", ' . $system, 'ibm-plex-sans', array( 400, 500, 600, 700 ), true ),
		'spacegro' => array( 'Space Grotesk', '"Space Grotesk", ' . $system, 'space-grotesk', array( 400, 500, 600, 700 ), true ),
		'oswald'   => array( 'Oswald', '"Oswald", ' . $system, 'oswald', array( 400, 500, 600, 700 ), true ),
		'bitter'   => array( 'Bitter', '"Bitter", Georgia, serif', 'bitter', array( 400, 500, 600, 700 ), true ),
	);

	// The paid families are only in the paid package. Offering a choice that
	// cannot be delivered would put a name in the list and nothing behind it.
	if ( ! clevie_fonts_all_available() ) {
		foreach ( $fonts as $slug => $data ) {
			if ( ! empty( $data[4] ) ) {
				unset( $fonts[ $slug ] );
			}
		}
	}

	/**
	 * Filters the fonts the theme offers.
	 *
	 * @param array $fonts Fonts.
	 */
	return (array) apply_filters( 'clevie_fonts', $fonts );
}

/**
 * Is the full set available?
 *
 * @return bool
 */
function clevie_fonts_all_available() {
	if ( function_exists( 'clevie_can' ) ) {
		return (bool) clevie_can( 'fonts_all' );
	}

	return false;
}

/**
 * Font choices for a select control.
 *
 * @return array
 */
function clevie_font_choices() {
	$choices = array();

	foreach ( clevie_fonts() as $slug => $data ) {
		$choices[ $slug ] = $data[0];
	}

	return $choices;
}

/**
 * Load the chosen Google Fonts, if any.
 */
function clevie_enqueue_fonts() {
	$css = clevie_font_face_css();

	if ( '' === $css ) {
		return;
	}

	// Attached to the theme's own stylesheet rather than requested separately:
	// one file fewer, and the faces are there before the first paint.
	wp_add_inline_style( 'clevie-style', $css );
}
add_action( 'wp_enqueue_scripts', 'clevie_enqueue_fonts', 20 );

/**
 * The @font-face rules for whichever families are in use.
 *
 * The files sit in this theme and are served from this domain. Nothing is
 * fetched from Google: a visitor's address would reach them before the page had
 * even drawn, which needs consent that a privacy policy does not provide.
 *
 * @return string
 */
function clevie_font_face_css() {
	$fonts = clevie_fonts();
	$used  = array();

	foreach ( array( 'clevie_font_body', 'clevie_font_heading' ) as $setting ) {
		$slug = get_theme_mod( $setting, 'system' );

		if ( isset( $fonts[ $slug ] ) && ! empty( $fonts[ $slug ][2] ) ) {
			$used[ $slug ] = $fonts[ $slug ];
		}
	}

	if ( ! $used ) {
		return '';
	}

	$base = get_template_directory_uri() . '/assets/fonts/';
	$dir  = get_template_directory() . '/assets/fonts/';
	$css  = '';

	foreach ( $used as $data ) {
		$family = trim( explode( ',', $data[1] )[0], '"\' ' );

		foreach ( (array) $data[3] as $weight ) {
			$file = $data[2] . '/' . (int) $weight . '.woff2';

			// A missing file would give the browser a face pointing at a 404,
			// and it would draw nothing until that came back.
			if ( ! file_exists( $dir . $file ) ) {
				continue;
			}

			$css .= sprintf(
				'@font-face{font-family:"%1$s";font-style:normal;font-weight:%2$d;font-display:swap;src:url(%3$s) format("woff2");}',
				esc_attr( $family ),
				(int) $weight,
				esc_url( $base . $file )
			);
		}
	}

	return $css;
}

/**
 * Typography variables for the inline stylesheet.
 *
 * @param string $css Existing CSS.
 * @return string
 */
function clevie_typography_css( $css ) {
	$fonts   = clevie_fonts();
	$body    = get_theme_mod( 'clevie_font_body', 'system' );
	$heading = get_theme_mod( 'clevie_font_heading', 'system' );

	$body    = isset( $fonts[ $body ] ) ? $fonts[ $body ][1] : $fonts['system'][1];
	$heading = isset( $fonts[ $heading ] ) ? $fonts[ $heading ][1] : $fonts['system'][1];

	$vars = sprintf(
		'--cv-font:%1$s;--cv-font-heading:%2$s;--cv-font-size:%3$dpx;--cv-heading-weight:%4$d;--cv-heading-spacing:%5$spx;--cv-line-height:%6$s;',
		$body,
		$heading,
		absint( get_theme_mod( 'clevie_font_size', 14 ) ),
		absint( get_theme_mod( 'clevie_heading_weight', 600 ) ),
		(float) get_theme_mod( 'clevie_heading_spacing', 0 ),
		(float) get_theme_mod( 'clevie_line_height', 1.5 )
	);

	$css .= ':root{' . $vars . '}';

	if ( get_theme_mod( 'clevie_heading_uppercase', false ) ) {
		$css .= '.cv-post__title,.cv-mag__title{text-transform:uppercase;}';
	}

	if ( ! get_theme_mod( 'clevie_link_underline', true ) ) {
		$css .= '.cv-entry a:hover{text-decoration:none;}';
	}

	return $css;
}
add_filter( 'clevie_inline_css', 'clevie_typography_css' );

/**
 * Register the typography controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function clevie_typography_customize( $wp_customize ) {
	$wp_customize->add_section( 'clevie_typography', array(
		'title'       => __( 'Typography', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => clevie_upgrade_notice( 'typography' ) . __( 'Fonts for the whole site. A Google font is only loaded once you pick one; the system font needs no external request.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_font_body', array(
		'default'           => 'system',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_font_body', array(
		'label'   => __( 'Body font', 'clevie-social' ),
		'section' => 'clevie_typography',
		'type'    => 'select',
		'choices' => clevie_font_choices(),
	) );

	$wp_customize->add_setting( 'clevie_font_heading', array(
		'default'           => 'system',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_font_heading', array(
		'label'   => __( 'Heading font', 'clevie-social' ),
		'section' => 'clevie_typography',
		'type'    => 'select',
		'choices' => clevie_font_choices(),
	) );

	$wp_customize->add_setting( 'clevie_font_size', array(
		'default'           => 14,
		'sanitize_callback' => 'absint',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'clevie_font_size', array(
		'label'       => __( 'Base font size', 'clevie-social' ),
		'description' => __( 'The base size of the body text in pixels. Headings scale with it.', 'clevie-social' ),
		'section'     => 'clevie_typography',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 12, 'max' => 20, 'step' => 1 ),
	) );

	$wp_customize->add_setting( 'clevie_line_height', array(
		'default'           => 1.5,
		'sanitize_callback' => 'clevie_sanitize_float',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'clevie_line_height', array(
		'label'       => __( 'Line height', 'clevie-social' ),
		'description' => __( 'The space between two lines, as a multiple of the font size. Around 1.6 reads well for long text.', 'clevie-social' ),
		'section'     => 'clevie_typography',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 1.2, 'max' => 2, 'step' => 0.05 ),
	) );

	$wp_customize->add_setting( 'clevie_heading_weight', array(
		'default'           => 600,
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_heading_weight', array(
		'label'   => __( 'Heading weight', 'clevie-social' ),
		'section' => 'clevie_typography',
		'type'    => 'select',
		'choices' => array(
			'400' => __( 'Regular', 'clevie-social' ),
			'500' => __( 'Medium', 'clevie-social' ),
			'600' => __( 'Semi bold', 'clevie-social' ),
			'700' => __( 'Bold', 'clevie-social' ),
			'800' => __( 'Extra bold', 'clevie-social' ),
		),
	) );

	$wp_customize->add_setting( 'clevie_heading_spacing', array(
		'default'           => 0,
		'sanitize_callback' => 'clevie_sanitize_float',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'clevie_heading_spacing', array(
		'label'       => __( 'Letter spacing of headings', 'clevie-social' ),
		'description' => __( 'The space between the letters of a heading, in thousandths of the font size. Negative values pull them together.', 'clevie-social' ),
		'section'     => 'clevie_typography',
		'type'        => 'number',
		'input_attrs' => array( 'min' => -2, 'max' => 4, 'step' => 0.1 ),
	) );

	$wp_customize->add_setting( 'clevie_heading_uppercase', array(
		'default'           => false,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_heading_uppercase', array(
		'label'   => __( 'Post titles in capital letters', 'clevie-social' ),
		'section' => 'clevie_typography',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_link_underline', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_link_underline', array(
		'label'   => __( 'Underline links inside posts on hover', 'clevie-social' ),
		'section' => 'clevie_typography',
		'type'    => 'checkbox',
	) );
}
add_action( 'customize_register', 'clevie_typography_customize', 12 );
