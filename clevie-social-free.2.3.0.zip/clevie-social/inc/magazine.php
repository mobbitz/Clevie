<?php
/**
 * Magazine area: layout styles, Customizer defaults and per-page settings.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options available for the magazine settings.
 *
 * @return array
 */
function clevie_magazine_choices() {
	return array(
		'style' => array(
			'list'    => __( 'List – full width, one story per row', 'clevie-social' ),
			'grid'    => __( 'Grid – tiles of equal height side by side', 'clevie-social' ),
			'masonry' => __( 'Masonry – staggered tiles of varying height', 'clevie-social' ),
		),
		'columns' => array(
			'2' => __( '2 columns', 'clevie-social' ),
			'3' => __( '3 columns', 'clevie-social' ),
			'4' => __( '4 columns', 'clevie-social' ),
			'5' => __( '5 columns', 'clevie-social' ),
		),
		'image' => array(
			'top'  => __( 'Image above the text', 'clevie-social' ),
			'side' => __( 'Image beside the text', 'clevie-social' ),
			'none' => __( 'No image', 'clevie-social' ),
		),
		'sidebar' => array(
			'show' => __( 'Show the right sidebar', 'clevie-social' ),
			'hide' => __( 'Hide the right sidebar', 'clevie-social' ),
		),
	);
}

/**
 * Global defaults from the Customizer.
 *
 * @return array
 */
function clevie_magazine_defaults() {
	return array(
		'style'        => get_theme_mod( 'clevie_mag_style', 'grid' ),
		'columns'      => (string) get_theme_mod( 'clevie_mag_columns', '3' ),
		'image'        => get_theme_mod( 'clevie_mag_image', 'top' ),
		'sidebar'      => get_theme_mod( 'clevie_mag_sidebar', 'hide' ),
		'per_page'     => (int) get_theme_mod( 'clevie_mag_per_page', 12 ),
		'category'     => (int) get_theme_mod( 'clevie_mag_category', 0 ),
		'show_meta'    => (bool) get_theme_mod( 'clevie_mag_show_meta', true ),
		'show_excerpt' => (bool) get_theme_mod( 'clevie_mag_show_excerpt', true ),
	);
}

/**
 * Settings for one magazine page. Values stored on the page beat the
 * Customizer defaults; an empty value keeps the default.
 *
 * @param int|null $post_id Page ID.
 * @return array
 */
function clevie_magazine_settings( $post_id = null ) {
	$settings = clevie_magazine_defaults();
	$post_id  = $post_id ? $post_id : get_the_ID();

	if ( ! $post_id ) {
		return $settings;
	}

	$choices = clevie_magazine_choices();

	foreach ( array( 'style', 'columns', 'image', 'sidebar' ) as $key ) {
		$value = get_post_meta( $post_id, '_clevie_mag_' . $key, true );
		if ( $value && isset( $choices[ $key ][ $value ] ) ) {
			$settings[ $key ] = $value;
		}
	}

	$per_page = get_post_meta( $post_id, '_clevie_mag_per_page', true );
	if ( '' !== $per_page && (int) $per_page > 0 ) {
		$settings['per_page'] = (int) $per_page;
	}

	$category = get_post_meta( $post_id, '_clevie_mag_category', true );
	if ( '' !== $category ) {
		$settings['category'] = (int) $category;
	}

	return apply_filters( 'clevie_magazine_settings', $settings, $post_id );
}

/**
 * CSS classes for the magazine grid.
 *
 * @param array $settings Settings.
 * @return string
 */
function clevie_magazine_classes( $settings ) {
	$classes = array( 'cv-mag', 'cv-mag--' . $settings['style'], 'cv-mag--img-' . $settings['image'] );

	if ( 'list' !== $settings['style'] ) {
		$classes[] = 'cv-mag--cols-' . $settings['columns'];
	}

	return implode( ' ', array_map( 'sanitize_html_class', $classes ) );
}

/**
 * The five ways a list of posts can look.
 *
 * @param bool $with_default Include the "use the default" entry.
 * @return array
 */
function clevie_view_styles( $with_default = true ) {
	$styles = array(
		'feed'    => __( 'Feed with cards', 'clevie-social' ),
		'list'    => __( 'Magazine: list', 'clevie-social' ),
		'grid'    => __( 'Magazine: grid', 'clevie-social' ),
		'masonry' => __( 'Magazine: masonry', 'clevie-social' ),
	);

	if ( $with_default ) {
		return array_merge( array( '' => __( 'Default', 'clevie-social' ) ), $styles );
	}

	return $styles;
}

/**
 * How the current view wants to look. A topic may decide for itself, the front
 * page has its own setting, and everything else falls back to the defaults.
 *
 * @return array Style, columns and the magazine settings that belong to it.
 */
function clevie_view_settings() {
	$settings = clevie_magazine_defaults();
	$style    = '';
	$columns  = '';

	if ( is_category() ) {
		$term_id = (int) get_queried_object_id();
		$style   = (string) get_term_meta( $term_id, 'clevie_view_style', true );
		$columns = (string) get_term_meta( $term_id, 'clevie_view_cols', true );
	} elseif ( is_home() || is_front_page() ) {
		$style   = (string) get_theme_mod( 'clevie_home_style', '' );
		$columns = (string) get_theme_mod( 'clevie_home_cols', '' );
	}

	// The magazine layouts belong to the paid edition. The feed is free and is
	// what the free edition falls back to.
	if ( $style && 'feed' !== $style && ! clevie_can( 'magazine' ) ) {
		$style = 'feed';
	}

	if ( ! $style || ! array_key_exists( $style, clevie_view_styles( false ) ) ) {
		// Nothing chosen here, so the global switch decides.
		$style = ( clevie_can( 'magazine' ) && get_theme_mod( 'clevie_mag_archives', false ) && ( is_home() || is_archive() || is_search() ) )
			? $settings['style']
			: 'feed';
	}

	if ( $columns && isset( clevie_magazine_choices()['columns'][ $columns ] ) ) {
		$settings['columns'] = $columns;
	}

	$settings['style'] = ( 'feed' === $style ) ? $settings['style'] : $style;
	$settings['mode']  = ( 'feed' === $style ) ? 'feed' : 'magazine';

	return $settings;
}

/**
 * Use the magazine layout for the current list of posts?
 *
 * @return bool
 */
function clevie_archives_use_magazine() {
	$settings = clevie_view_settings();

	return ( 'magazine' === $settings['mode'] );
}

/* =========================================================
 * Customizer
 * ========================================================= */

/**
 * Categories as a list of choices.
 *
 * @return array
 */
function clevie_category_choices() {
	$choices    = array( 0 => __( 'All categories', 'clevie-social' ) );
	$categories = get_categories( array( 'hide_empty' => false ) );

	foreach ( $categories as $category ) {
		$choices[ $category->term_id ] = $category->name;
	}

	return $choices;
}

/**
 * Register the magazine options in the Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function clevie_magazine_customize( $wp_customize ) {
	$choices = clevie_magazine_choices();

	$magazine_note = clevie_upgrade_notice( 'magazine' );

	$wp_customize->add_section( 'clevie_magazine', array(
		'title'       => __( 'Magazine', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => $magazine_note . __( 'Defaults for pages using the “Magazine” template, and for the front page and archives when set below. Every magazine page can override them in the editor.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_mag_style', array(
		'default'           => 'grid',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_mag_style', array(
		'label'   => __( 'Layout', 'clevie-social' ),
		'description' => __( 'List is one post per row, grid is even tiles, masonry is tiles of different heights.', 'clevie-social' ),
		'section' => 'clevie_magazine',
		'type'    => 'select',
		'choices' => $choices['style'],
	) );

	$wp_customize->add_setting( 'clevie_mag_columns', array(
		'default'           => '3',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_mag_columns', array(
		'label'       => __( 'Columns', 'clevie-social' ),
		'description' => __( 'An upper limit for grid and masonry. Fewer columns are shown whenever the room is tight.', 'clevie-social' ),
		'section'     => 'clevie_magazine',
		'type'        => 'select',
		'choices'     => $choices['columns'],
	) );

	$wp_customize->add_setting( 'clevie_mag_image', array(
		'default'           => 'top',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_mag_image', array(
		'label'       => __( 'Image position', 'clevie-social' ),
		'description' => __( 'In the masonry layout the image always sits on top.', 'clevie-social' ),
		'section'     => 'clevie_magazine',
		'type'        => 'select',
		'choices'     => $choices['image'],
	) );

	$wp_customize->add_setting( 'clevie_mag_sidebar', array(
		'default'           => 'hide',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_mag_sidebar', array(
		'label'   => __( 'Right sidebar in the magazine', 'clevie-social' ),
		'description' => __( 'Whether a magazine page keeps the right sidebar or uses the full width.', 'clevie-social' ),
		'section' => 'clevie_magazine',
		'type'    => 'select',
		'choices' => $choices['sidebar'],
	) );

	$wp_customize->add_setting( 'clevie_mag_category', array(
		'default'           => 0,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_mag_category', array(
		'label'   => __( 'Posts from category', 'clevie-social' ),
		'description' => __( 'Which topic a magazine page draws from. Empty draws from all of them.', 'clevie-social' ),
		'section' => 'clevie_magazine',
		'type'    => 'select',
		'choices' => clevie_category_choices(),
	) );

	$wp_customize->add_setting( 'clevie_mag_per_page', array(
		'default'           => 12,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_mag_per_page', array(
		'label'       => __( 'Posts per page', 'clevie-social' ),
		'description' => __( 'Posts per page in the magazine layout, before the pagination starts.', 'clevie-social' ),
		'section'     => 'clevie_magazine',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 1, 'max' => 60 ),
	) );

	$wp_customize->add_setting( 'clevie_mag_show_meta', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_mag_show_meta', array(
		'label'   => __( 'Show category, author and date', 'clevie-social' ),
		'section' => 'clevie_magazine',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_mag_show_excerpt', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_mag_show_excerpt', array(
		'label'   => __( 'Show the excerpt', 'clevie-social' ),
		'section' => 'clevie_magazine',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_home_style', array(
		'default'           => '',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_home_style', array(
		'label'       => __( 'Layout of the front page', 'clevie-social' ),
		'description' => __( 'How the posts on the front page are listed. Every topic can set its own under Posts, Categories.', 'clevie-social' ),
		'section'     => 'clevie_magazine',
		'type'        => 'select',
		'choices'     => clevie_view_styles(),
	) );

	$wp_customize->add_setting( 'clevie_home_cols', array(
		'default'           => '',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_home_cols', array(
		'label'   => __( 'Columns on the front page', 'clevie-social' ),
		'section' => 'clevie_magazine',
		'type'    => 'select',
		'choices' => array_merge( array( '' => __( 'Default', 'clevie-social' ) ), $choices['columns'] ),
	) );

	$wp_customize->add_setting( 'clevie_mag_archives', array(
		'default'           => false,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_mag_archives', array(
		'label'       => __( 'Use the magazine layout for the blog, archives and search as well', 'clevie-social' ),
		'description' => __( 'Uses the magazine layout above wherever no other layout is set for the topic or the front page.', 'clevie-social' ),
		'section'     => 'clevie_magazine',
		'type'        => 'checkbox',
	) );
}
add_action( 'customize_register', 'clevie_magazine_customize', 20 );

/* =========================================================
 * Meta box in the page editor
 * ========================================================= */

/**
 * Register the meta box.
 */
function clevie_magazine_meta_box() {
	add_meta_box(
		'clevie-magazine',
		__( 'Magazine layout', 'clevie-social' ),
		'clevie_magazine_meta_box_html',
		'page',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'clevie_magazine_meta_box' );

/**
 * Content of the meta box.
 *
 * @param WP_Post $post Page.
 */
function clevie_magazine_meta_box_html( $post ) {
	wp_nonce_field( 'clevie_magazine_save', 'clevie_magazine_nonce' );

	$choices  = clevie_magazine_choices();
	$defaults = clevie_magazine_defaults();

	$fields = array(
		'style'   => __( 'Layout', 'clevie-social' ),
		'columns' => __( 'Columns', 'clevie-social' ),
		'image'   => __( 'Image position', 'clevie-social' ),
		'sidebar' => __( 'Right sidebar', 'clevie-social' ),
	);

	echo '<p style="margin-top:0;">' . esc_html__( 'Only applies to the “Magazine” page template. “Default” keeps the setting from the Customizer.', 'clevie-social' ) . '</p>';

	foreach ( $fields as $key => $label ) {
		$value = get_post_meta( $post->ID, '_clevie_mag_' . $key, true );
		printf( '<p><label for="cv-mag-%1$s"><strong>%2$s</strong></label><br>', esc_attr( $key ), esc_html( $label ) );
		printf( '<select id="cv-mag-%1$s" name="clevie_mag_%1$s" style="width:100%%;">', esc_attr( $key ) );
		printf(
			'<option value="">%s</option>',
			esc_html( sprintf( /* translators: %s: current default value. */ __( 'Default (%s)', 'clevie-social' ), $choices[ $key ][ $defaults[ $key ] ] ) )
		);
		foreach ( $choices[ $key ] as $option => $option_label ) {
			printf(
				'<option value="%1$s" %2$s>%3$s</option>',
				esc_attr( $option ),
				selected( $value, $option, false ),
				esc_html( $option_label )
			);
		}
		echo '</select></p>';
	}

	$category = get_post_meta( $post->ID, '_clevie_mag_category', true );
	echo '<p><label for="cv-mag-category"><strong>' . esc_html__( 'Category', 'clevie-social' ) . '</strong></label><br>';
	echo '<select id="cv-mag-category" name="clevie_mag_category" style="width:100%;">';
	printf( '<option value="">%s</option>', esc_html__( 'Default', 'clevie-social' ) );
	foreach ( clevie_category_choices() as $term_id => $name ) {
		printf(
			'<option value="%1$d" %2$s>%3$s</option>',
			(int) $term_id,
			selected( (string) $category, (string) $term_id, false ),
			esc_html( $name )
		);
	}
	echo '</select></p>';

	$per_page = get_post_meta( $post->ID, '_clevie_mag_per_page', true );
	echo '<p><label for="cv-mag-per-page"><strong>' . esc_html__( 'Posts per page', 'clevie-social' ) . '</strong></label><br>';
	printf(
		'<input type="number" min="1" max="60" id="cv-mag-per-page" name="clevie_mag_per_page" value="%s" placeholder="%s" style="width:100%%;"></p>',
		esc_attr( $per_page ),
		esc_attr( $defaults['per_page'] )
	);
}

/**
 * Save the meta box.
 *
 * @param int $post_id Page ID.
 */
function clevie_magazine_save( $post_id ) {
	if ( ! isset( $_POST['clevie_magazine_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['clevie_magazine_nonce'] ) ), 'clevie_magazine_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$choices = clevie_magazine_choices();

	foreach ( array( 'style', 'columns', 'image', 'sidebar' ) as $key ) {
		$field = 'clevie_mag_' . $key;
		$value = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';

		if ( $value && isset( $choices[ $key ][ $value ] ) ) {
			update_post_meta( $post_id, '_clevie_mag_' . $key, $value );
		} else {
			delete_post_meta( $post_id, '_clevie_mag_' . $key );
		}
	}

	if ( isset( $_POST['clevie_mag_category'] ) && '' !== $_POST['clevie_mag_category'] ) {
		update_post_meta( $post_id, '_clevie_mag_category', absint( wp_unslash( $_POST['clevie_mag_category'] ) ) );
	} else {
		delete_post_meta( $post_id, '_clevie_mag_category' );
	}

	if ( isset( $_POST['clevie_mag_per_page'] ) && '' !== $_POST['clevie_mag_per_page'] ) {
		update_post_meta( $post_id, '_clevie_mag_per_page', absint( wp_unslash( $_POST['clevie_mag_per_page'] ) ) );
	} else {
		delete_post_meta( $post_id, '_clevie_mag_per_page' );
	}
}
add_action( 'save_post_page', 'clevie_magazine_save' );

/* =========================================================
 * Layout of a single topic, on the category screen
 * ========================================================= */

/**
 * Two fields on the category edit screen.
 *
 * @param WP_Term $term Term.
 */
function clevie_view_term_fields( $term ) {
	$style   = (string) get_term_meta( $term->term_id, 'clevie_view_style', true );
	$columns = (string) get_term_meta( $term->term_id, 'clevie_view_cols', true );
	$choices = clevie_magazine_choices();

	wp_nonce_field( 'clevie_view_term', 'clevie_view_term_nonce' );
	?>
	<tr class="form-field">
		<th scope="row"><label for="clevie_view_style"><?php esc_html_e( 'Layout of this topic', 'clevie-social' ); ?></label></th>
		<td>
			<select id="clevie_view_style" name="clevie_view_style">
				<?php foreach ( clevie_view_styles() as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $style, $key ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'How the posts of this topic are listed. Without a choice the default from the Customizer is used.', 'clevie-social' ); ?></p>
		</td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="clevie_view_cols"><?php esc_html_e( 'Columns', 'clevie-social' ); ?></label></th>
		<td>
			<select id="clevie_view_cols" name="clevie_view_cols">
				<option value=""><?php esc_html_e( 'Default', 'clevie-social' ); ?></option>
				<?php foreach ( $choices['columns'] as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $columns, $key ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'An upper limit for grid and masonry. Fewer columns are shown whenever the room is tight.', 'clevie-social' ); ?></p>
		</td>
	</tr>
	<?php
}
add_action( 'category_edit_form_fields', 'clevie_view_term_fields', 5 );

/**
 * Save both fields.
 *
 * @param int $term_id Term ID.
 */
function clevie_view_save_term( $term_id ) {
	if ( ! isset( $_POST['clevie_view_term_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['clevie_view_term_nonce'] ) ), 'clevie_view_term' ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_categories' ) ) {
		return;
	}

	$style = isset( $_POST['clevie_view_style'] ) ? sanitize_key( wp_unslash( $_POST['clevie_view_style'] ) ) : '';

	if ( $style && array_key_exists( $style, clevie_view_styles( false ) ) ) {
		update_term_meta( $term_id, 'clevie_view_style', $style );
	} else {
		delete_term_meta( $term_id, 'clevie_view_style' );
	}

	$columns = isset( $_POST['clevie_view_cols'] ) ? sanitize_key( wp_unslash( $_POST['clevie_view_cols'] ) ) : '';
	$choices = clevie_magazine_choices();

	if ( $columns && isset( $choices['columns'][ $columns ] ) ) {
		update_term_meta( $term_id, 'clevie_view_cols', $columns );
	} else {
		delete_term_meta( $term_id, 'clevie_view_cols' );
	}
}
add_action( 'edited_category', 'clevie_view_save_term' );
