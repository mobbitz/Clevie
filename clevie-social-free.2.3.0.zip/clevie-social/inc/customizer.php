<?php
/**
 * Customizer settings for Clevie Social.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All color settings as a map: setting ID => CSS variable, label, default.
 *
 * @param string $mode 'light' or 'dark'.
 * @return array
 */
function clevie_color_map( $mode = 'light' ) {
	$light = array(
		'clevie_light_bg'        => array( '--cv-bg', __( 'Page background', 'clevie-social' ), '#dae0e6' ),
		'clevie_light_surface'   => array( '--cv-surface', __( 'Cards and boxes', 'clevie-social' ), '#ffffff' ),
		'clevie_light_surface_2' => array( '--cv-surface-2', __( 'Second surface (hover, votes)', 'clevie-social' ), '#f6f7f8' ),
		'clevie_light_header'    => array( '--cv-header-bg', __( 'Header', 'clevie-social' ), '#ffffff' ),
		'clevie_light_leftbar'   => array( '--cv-left-bg', __( 'Left sidebar', 'clevie-social' ), '#ffffff' ),
		'clevie_light_text'      => array( '--cv-text', __( 'Text color', 'clevie-social' ), '#1c1c1c' ),
		'clevie_light_muted'     => array( '--cv-muted', __( 'Secondary text', 'clevie-social' ), '#7c7c7c' ),
		'clevie_light_border'    => array( '--cv-border', __( 'Borders and rules', 'clevie-social' ), '#cccccc' ),
		'clevie_light_accent'    => array( '--cv-accent', __( 'Accent (upvote orange)', 'clevie-social' ), '#ff4500' ),
		'clevie_light_blue'      => array( '--cv-blue', __( 'Buttons', 'clevie-social' ), '#0079d3' ),
		'clevie_light_link'      => array( '--cv-link', __( 'Links', 'clevie-social' ), '#0079d3' ),
	);

	$dark = array(
		'clevie_dark_bg'        => array( '--cv-bg', __( 'Page background', 'clevie-social' ), '#030303' ),
		'clevie_dark_surface'   => array( '--cv-surface', __( 'Cards and boxes', 'clevie-social' ), '#1a1a1b' ),
		'clevie_dark_surface_2' => array( '--cv-surface-2', __( 'Second surface (hover, votes)', 'clevie-social' ), '#272729' ),
		'clevie_dark_header'    => array( '--cv-header-bg', __( 'Header', 'clevie-social' ), '#1a1a1b' ),
		'clevie_dark_leftbar'   => array( '--cv-left-bg', __( 'Left sidebar', 'clevie-social' ), '#0e0e0f' ),
		'clevie_dark_text'      => array( '--cv-text', __( 'Text color', 'clevie-social' ), '#d7dadc' ),
		'clevie_dark_muted'     => array( '--cv-muted', __( 'Secondary text', 'clevie-social' ), '#818384' ),
		'clevie_dark_border'    => array( '--cv-border', __( 'Borders and rules', 'clevie-social' ), '#343536' ),
		'clevie_dark_accent'    => array( '--cv-accent', __( 'Accent (upvote orange)', 'clevie-social' ), '#ff4500' ),
		'clevie_dark_blue'      => array( '--cv-blue', __( 'Buttons', 'clevie-social' ), '#4f9eed' ),
		'clevie_dark_link'      => array( '--cv-link', __( 'Links', 'clevie-social' ), '#4f9eed' ),
	);

	return ( 'dark' === $mode ) ? $dark : $light;
}

/**
 * Numeric layout values: setting ID => CSS variable, label, default, min, max, unit.
 *
 * @return array
 */
function clevie_layout_map() {
	return array(
		'clevie_content_width' => array( '--cv-content-width', __( 'Width of the feed', 'clevie-social' ), 820, 480, 1200, 'px' ),
		'clevie_left_width'    => array( '--cv-left-width', __( 'Width of the left column', 'clevie-social' ), 260, 180, 380, 'px' ),
		'clevie_right_width'   => array( '--cv-right-width', __( 'Width of the right sidebar', 'clevie-social' ), 312, 220, 420, 'px' ),
		'clevie_gap'           => array( '--cv-gap', __( 'Gap between the columns', 'clevie-social' ), 24, 8, 64, 'px' ),
		'clevie_radius'        => array( '--cv-radius', __( 'Corner radius', 'clevie-social' ), 4, 0, 20, 'px' ),
		'clevie_header_height' => array( '--cv-header-height', __( 'Height of the header', 'clevie-social' ), 56, 44, 96, 'px' ),
		'clevie_logo_height'   => array( '--cv-logo-height', __( 'Height of the logo', 'clevie-social' ), 34, 16, 80, 'px' ),
		'clevie_thumb_max'     => array( '--cv-thumb-max', __( 'Tallest a picture may get in a post', 'clevie-social' ), 620, 200, 1200, 'px' ),
		'clevie_wide_width'    => array( '--cv-wide-width', __( 'Width for “No sidebars, wide”', 'clevie-social' ), 900, 640, 1400, 'px' ),
		'clevie_mag_width'     => array( '--cv-mag-width', __( 'Width of the magazine area', 'clevie-social' ), 1120, 640, 1600, 'px' ),
		'clevie_fold_height'   => array( '--cv-fold-height', __( 'How much of a post the stream shows', 'clevie-social' ), 380, 150, 1200, 'px' ),
	);
}

/**
 * Sanitize a checkbox.
 *
 * @param mixed $value Value.
 * @return bool
 */
function clevie_sanitize_checkbox( $value ) {
	return ( isset( $value ) && true === (bool) $value );
}

/**
 * Sanitize a decimal number.
 *
 * @param mixed $value Value.
 * @return float
 */
function clevie_sanitize_float( $value ) {
	return (float) $value;
}

/**
 * Sanitize a select control.
 *
 * @param string               $value   Value.
 * @param WP_Customize_Setting $setting Setting.
 * @return string
 */
function clevie_sanitize_select( $value, $setting ) {
	$choices = $setting->manager->get_control( $setting->id )->choices;
	return array_key_exists( $value, $choices ) ? $value : $setting->default;
}

/**
 * Build the Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function clevie_customize_register( $wp_customize ) {

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

	$wp_customize->add_panel( 'clevie_panel', array(
		'title'    => __( 'Clevie Social Theme', 'clevie-social' ),
		'priority' => 20,
	) );

	/* ---------------------------------------------------------
	 * Color scheme
	 * --------------------------------------------------------- */
	$wp_customize->add_section( 'clevie_scheme', array(
		'title'       => __( 'Light / dark', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'Which mode a visitor gets first, and the eleven colours each mode is built from.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_color_scheme', array(
		'default'           => 'light',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_color_scheme', array(
		'label'       => __( 'Default mode for new visitors', 'clevie-social' ),
		'description' => __( 'Automatic follows the system setting of the visitor. Anyone who uses the toggle keeps their choice in this browser.', 'clevie-social' ),
		'section'     => 'clevie_scheme',
		'type'        => 'select',
		'choices'     => array(
			'light' => __( 'Light', 'clevie-social' ),
			'dark'  => __( 'Dark', 'clevie-social' ),
			'auto'  => __( 'Automatic (system setting)', 'clevie-social' ),
		),
	) );

	// Where the bell, the button and the light switch sit. Pushed to the far
	// right they are out of the way; next to the search field they are within
	// reach of the same hand, and on a wide screen that is a shorter journey
	// than crossing the whole header.
	$wp_customize->add_setting( 'clevie_header_actions', array(
		'default'           => 'right',
		'sanitize_callback' => 'clevie_sanitize_header_actions',
	) );
	$wp_customize->add_control( 'clevie_header_actions', array(
		'label'       => __( 'Bell, button and light switch', 'clevie-social' ),
		'description' => __( 'Where they go in the header. Beside the search field keeps them together with it; on the far right they stay out of the way.', 'clevie-social' ),
		'section'     => 'clevie_header',
		'type'        => 'radio',
		'choices'     => array(
			'right'  => __( 'On the far right', 'clevie-social' ),
			'search' => __( 'Beside the search field', 'clevie-social' ),
		),
	) );

	$wp_customize->add_setting( 'clevie_show_toggle', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_show_toggle', array(
		'label'   => __( 'Show the toggle in the header', 'clevie-social' ),
		'section' => 'clevie_scheme',
		'type'    => 'checkbox',
	) );

	/* ---------------------------------------------------------
	 * Light and dark colors
	 * --------------------------------------------------------- */
	foreach ( array( 'light', 'dark' ) as $mode ) {
		$section_id = 'clevie_colors_' . $mode;

		$wp_customize->add_section( $section_id, array(
			'title'       => ( 'light' === $mode ) ? __( 'Colors – light mode', 'clevie-social' ) : __( 'Colors – dark mode', 'clevie-social' ),
			'panel'       => 'clevie_panel',
			'description' => __( 'Colors for this mode. Use the toggle in the preview to see the other one.', 'clevie-social' ),
		) );

		foreach ( clevie_color_map( $mode ) as $id => $data ) {
			$wp_customize->add_setting( $id, array(
				'default'           => $data[2],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'postMessage',
			) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
				'label'   => $data[1],
				'section' => $section_id,
			) ) );
		}
	}

	/* ---------------------------------------------------------
	 * Layout
	 * --------------------------------------------------------- */
	$wp_customize->add_section( 'clevie_layout', array(
		'title'       => __( 'Layout and sizes', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'The width of the three columns and the measurements that go with them. Below 1000 pixels the sidebars fold away by themselves, whatever is set here.', 'clevie-social' ),
	) );

	foreach ( clevie_layout_map() as $id => $data ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $data[2],
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		) );
		$wp_customize->add_control( $id, array(
			'label'       => $data[1],
			'section'     => 'clevie_layout',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => $data[3],
				'max'  => $data[4],
				'step' => 1,
			),
		) );
	}

	$wp_customize->add_setting( 'clevie_sticky_header', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_sticky_header', array(
		'label'   => __( 'Keep the header fixed while scrolling', 'clevie-social' ),
		'section' => 'clevie_layout',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_show_left_column', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_show_left_column', array(
		'label'       => __( 'Show the left column', 'clevie-social' ),
		'description' => __( 'Holds the primary menu and the widget area “Left sidebar (below the menu)”.', 'clevie-social' ),
		'section'     => 'clevie_layout',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_leftbar_fixed', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_leftbar_fixed', array(
		'label'       => __( 'Left column flush with the screen edge', 'clevie-social' ),
		'description' => __( 'The sidebar sits at the left edge, runs from the header to the bottom of the screen and scrolls on its own. Unchecked, it stands as a column of cards inside the content area.', 'clevie-social' ),
		'section'     => 'clevie_layout',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_backtotop', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_backtotop', array(
		'label'   => __( 'Show the “Back to top” button', 'clevie-social' ),
		'section' => 'clevie_layout',
		'type'    => 'checkbox',
	) );

	/* ---------------------------------------------------------
	 * Header
	 * --------------------------------------------------------- */
	$wp_customize->add_section( 'clevie_header', array(
		'title'       => __( 'Header', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'The bar at the top of every page: the search field and one button of your own. The logo itself is under Site Identity.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_show_search', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_show_search', array(
		'label'   => __( 'Show the search field', 'clevie-social' ),
		'section' => 'clevie_header',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_search_placeholder', array(
		'default'           => __( 'Search', 'clevie-social' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'clevie_search_placeholder', array(
		'label'   => __( 'Placeholder in the search field', 'clevie-social' ),
		'section' => 'clevie_header',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'clevie_button_text', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'clevie_button_text', array(
		'label'       => __( 'Label of the header button', 'clevie-social' ),
		'description' => __( 'Leave empty to hide the button.', 'clevie-social' ),
		'section'     => 'clevie_header',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'clevie_button_url', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'clevie_button_url', array(
		'label'   => __( 'Link of the header button', 'clevie-social' ),
		'section' => 'clevie_header',
		'type'    => 'url',
	) );

	/* ---------------------------------------------------------
	 * Feed
	 * --------------------------------------------------------- */
	$wp_customize->add_section( 'clevie_feed', array(
		'title'       => __( 'Post feed', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'How a post looks in a list: the vote element, the picture and how much of the text is shown.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_feed_style', array(
		'default'           => 'card',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_feed_style', array(
		'label'   => __( 'Layout', 'clevie-social' ),
		'description' => __( 'Cards give every post its own box; compact puts them in one list with a small picture on the right.', 'clevie-social' ),
		'section' => 'clevie_feed',
		'type'    => 'select',
		'choices' => array(
			'card'    => __( 'Cards (with image and excerpt)', 'clevie-social' ),
			'compact' => __( 'Compact (small thumbnails)', 'clevie-social' ),
		),
	) );

	$wp_customize->add_setting( 'clevie_show_votes', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_show_votes', array(
		'label'       => __( 'Show the vote column', 'clevie-social' ),
		'description' => __( 'The arrows are decorative on their own; the Clevie Community plugin makes them work. Without it the number shows the comment count or the custom field “clevie_score”.', 'clevie-social' ),
		'section'     => 'clevie_feed',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_vote_style', array(
		'default'           => 'bar',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_vote_style', array(
		'label'       => __( 'Position of the vote element', 'clevie-social' ),
		'description' => __( 'The arrows are decorative on their own. A voting plugin can attach to the classes cv-vote-up and cv-vote-down.', 'clevie-social' ),
		'section'     => 'clevie_feed',
		'type'        => 'select',
		'choices'     => array(
			'bar'    => __( 'Horizontal, above and below the post', 'clevie-social' ),
			'column' => __( 'Vertical column on the left', 'clevie-social' ),
		),
	) );

	$wp_customize->add_setting( 'clevie_show_thumbs', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_show_thumbs', array(
		'label'   => __( 'Show featured images in the feed', 'clevie-social' ),
		'section' => 'clevie_feed',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_excerpt_length', array(
		'default'           => 30,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_excerpt_length', array(
		'label'       => __( 'Excerpt length (words)', 'clevie-social' ),
		'description' => __( 'Words of the text shown in a list. Zero shows the whole post.', 'clevie-social' ),
		'section'     => 'clevie_feed',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 5, 'max' => 100 ),
	) );

	/* ---------------------------------------------------------
	 * Labels
	 * --------------------------------------------------------- */
	$wp_customize->add_section( 'clevie_labels', array(
		'title'       => __( 'Labels', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'The short prefixes in front of topic and member names.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_topic_prefix', array(
		'default'           => 'to/',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'clevie_topic_prefix', array(
		'label'       => __( 'Prefix for topics', 'clevie-social' ),
		'description' => __( 'Appears in front of a topic name, for example to/travel. Leave empty for none.', 'clevie-social' ),
		'section'     => 'clevie_labels',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'clevie_user_prefix', array(
		'default'           => 'm/',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'clevie_user_prefix', array(
		'label'       => __( 'Prefix for members', 'clevie-social' ),
		'description' => __( 'Appears in front of the member name, for example m/anna.', 'clevie-social' ),
		'section'     => 'clevie_labels',
		'type'        => 'text',
	) );

	/* ---------------------------------------------------------
	 * Footer
	 * --------------------------------------------------------- */
	$wp_customize->add_section( 'clevie_footer', array(
		'title'       => __( 'Footer', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'The columns at the bottom of the page. What goes in them is set under Appearance, Widgets, in the Footer area.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_footer_columns', array(
		'default'           => 3,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_footer_columns', array(
		'label'       => __( 'Columns in the footer widget area', 'clevie-social' ),
		'description' => __( 'How many widget columns the footer has. What goes in them is set under Appearance, Widgets.', 'clevie-social' ),
		'section'     => 'clevie_footer',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 1, 'max' => 4 ),
	) );

	$wp_customize->add_setting( 'clevie_footer_text', array(
		'default'           => '',
		'sanitize_callback' => 'wp_kses_post',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'clevie_footer_text', array(
		'label'       => __( 'Text in the footer', 'clevie-social' ),
		'description' => __( 'Leave empty for the default line with the year and site title.', 'clevie-social' ),
		'section'     => 'clevie_footer',
		'type'        => 'textarea',
	) );

	/* Selective refresh */
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.cv-brand__name',
			'render_callback' => function () {
				return get_bloginfo( 'name' );
			},
		) );
		$wp_customize->selective_refresh->add_partial( 'clevie_footer_text', array(
			'selector'        => '.cv-footer__text',
			'render_callback' => function () {
				return wp_kses_post( get_theme_mod( 'clevie_footer_text', '' ) );
			},
		) );
	}
}
add_action( 'customize_register', 'clevie_customize_register' );

/**
 * Build CSS from the Customizer values.
 *
 * @return string
 */
function clevie_customizer_css() {
	$light = '';
	foreach ( clevie_color_map( 'light' ) as $id => $data ) {
		$light .= sprintf( '%s:%s;', $data[0], esc_attr( get_theme_mod( $id, $data[2] ) ) );
	}

	$dark = '';
	foreach ( clevie_color_map( 'dark' ) as $id => $data ) {
		$dark .= sprintf( '%s:%s;', $data[0], esc_attr( get_theme_mod( $id, $data[2] ) ) );
	}

	$layout = '';
	foreach ( clevie_layout_map() as $id => $data ) {
		$layout .= sprintf( '%s:%dpx;', $data[0], absint( get_theme_mod( $id, $data[2] ) ) );
	}

	$css = sprintf( ':root{%s%s}html[data-theme="dark"]{%s}', $light, $layout, $dark );

	/**
	 * Extra inline CSS from other theme modules.
	 *
	 * @param string $extra CSS.
	 */
	return $css . apply_filters( 'clevie_inline_css', '' );
}

/**
 * Script for the live preview inside the Customizer.
 */
function clevie_customize_preview_js() {
	wp_enqueue_script(
		'clevie-customizer-preview',
		get_template_directory_uri() . '/js/customizer-preview.js',
		array( 'customize-preview', 'jquery' ),
		CLEVIE_VERSION,
		true
	);

	$vars = array( 'light' => array(), 'dark' => array(), 'layout' => array() );
	foreach ( clevie_color_map( 'light' ) as $id => $data ) {
		$vars['light'][ $id ] = $data[0];
	}
	foreach ( clevie_color_map( 'dark' ) as $id => $data ) {
		$vars['dark'][ $id ] = $data[0];
	}
	foreach ( clevie_layout_map() as $id => $data ) {
		$vars['layout'][ $id ] = $data[0];
	}

	wp_localize_script( 'clevie-customizer-preview', 'cleviePreview', $vars );
}
add_action( 'customize_preview_init', 'clevie_customize_preview_js' );

/**
 * Keep the choice to the two that exist.
 *
 * @param string $value Submitted value.
 * @return string
 */
function clevie_sanitize_header_actions( $value ) {
	return ( 'search' === $value ) ? 'search' : 'right';
}

/**
 * Mark the choice on the body, so one rule can move them.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function clevie_header_actions_class( $classes ) {
	if ( 'search' !== get_theme_mod( 'clevie_header_actions', 'right' ) ) {
		return $classes;
	}

	// With the search field switched off there is nothing to sit beside, and
	// the actions would huddle against the logo with the rest of the header
	// empty. Decided here rather than in CSS, because the field is not printed
	// at all in that case and a stylesheet cannot see something that is absent.
	if ( ! get_theme_mod( 'clevie_show_search', true ) ) {
		return $classes;
	}

	$classes[] = 'cv-actions-by-search';

	return $classes;
}
add_filter( 'body_class', 'clevie_header_actions_class' );
