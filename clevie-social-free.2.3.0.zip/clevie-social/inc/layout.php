<?php
/**
 * Page layout: which columns show up in which view.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Available layouts.
 *
 * @return array
 */
function clevie_layout_choices() {
	return array(
		'both'  => __( 'Both sidebars (left and right)', 'clevie-social' ),
		'right' => __( 'Right sidebar only', 'clevie-social' ),
		'left'  => __( 'Left column only', 'clevie-social' ),
		'none'  => __( 'No sidebars, centered', 'clevie-social' ),
		'full'  => __( 'No sidebars, wide', 'clevie-social' ),
	);
}

/**
 * Layout of the current view.
 *
 * @return string
 */
function clevie_current_layout() {
	static $layout = null;

	if ( null !== $layout ) {
		return $layout;
	}

	$choices = clevie_layout_choices();

	if ( is_singular() ) {
		$meta = get_post_meta( get_queried_object_id(), '_clevie_layout', true );

		if ( $meta && isset( $choices[ $meta ] ) ) {
			$layout = $meta;
		} else {
			$default = is_page() ? get_theme_mod( 'clevie_layout_page', 'both' ) : get_theme_mod( 'clevie_layout_post', 'both' );
			$layout  = isset( $choices[ $default ] ) ? $default : 'both';
		}
	} else {
		$default = get_theme_mod( 'clevie_layout_archive', 'both' );
		$layout  = isset( $choices[ $default ] ) ? $default : 'both';
	}

	$layout = apply_filters( 'clevie_current_layout', $layout );

	return $layout;
}

/**
 * Is the left column active in this view?
 *
 * @return bool
 */
function clevie_left_column_active() {
	if ( ! get_theme_mod( 'clevie_show_left_column', true ) ) {
		return false;
	}

	if ( ! empty( $GLOBALS['clevie_hide_left_sidebar'] ) ) {
		return false;
	}

	if ( in_array( clevie_current_layout(), array( 'right', 'none', 'full' ), true ) ) {
		return false;
	}

	$active = has_nav_menu( 'primary' ) || is_active_sidebar( 'sidebar-left' );

	return (bool) apply_filters( 'clevie_left_column_active', $active );
}

/**
 * Is the right sidebar active in this view?
 *
 * @return bool
 */
function clevie_right_sidebar_active() {
	$active = is_active_sidebar( 'sidebar-right' );

	if ( ! empty( $GLOBALS['clevie_hide_right_sidebar'] ) ) {
		$active = false;
	}

	if ( in_array( clevie_current_layout(), array( 'left', 'none', 'full' ), true ) ) {
		$active = false;
	}

	return (bool) apply_filters( 'clevie_right_sidebar_active', $active );
}

/* =========================================================
 * Customizer: default layouts
 * ========================================================= */

/**
 * Register the layout defaults.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function clevie_layout_customize( $wp_customize ) {
	$choices = clevie_layout_choices();

	$defaults = array(
		'clevie_layout_post'    => __( 'Default layout for posts', 'clevie-social' ),
		'clevie_layout_page'    => __( 'Default layout for pages', 'clevie-social' ),
		'clevie_layout_archive' => __( 'Default layout for the blog, archives and search', 'clevie-social' ),
	);

	foreach ( $defaults as $id => $label ) {
		$wp_customize->add_setting( $id, array(
			'default'           => 'both',
			'sanitize_callback' => 'clevie_sanitize_select',
		) );
		$wp_customize->add_control( $id, array(
			'label'       => $label,
			'description' => ( 'clevie_layout_post' === $id )
				? __( 'Every post and page can override this in the editor under “Page layout”.', 'clevie-social' )
				: '',
			'section'     => 'clevie_layout',
			'type'        => 'select',
			'choices'     => $choices,
			'priority'    => 5,
		) );
	}
}
add_action( 'customize_register', 'clevie_layout_customize', 15 );

/* =========================================================
 * Meta box in the editor
 * ========================================================= */

/**
 * Meta box for posts and pages.
 */
function clevie_layout_meta_box() {
	foreach ( array( 'post', 'page' ) as $screen ) {
		add_meta_box(
			'clevie-layout',
			__( 'Page layout', 'clevie-social' ),
			'clevie_layout_meta_box_html',
			$screen,
			'side',
			'default'
		);
	}
}
add_action( 'add_meta_boxes', 'clevie_layout_meta_box' );

/**
 * Content of the meta box.
 *
 * @param WP_Post $post Post or page.
 */
function clevie_layout_meta_box_html( $post ) {
	wp_nonce_field( 'clevie_layout_save', 'clevie_layout_nonce' );

	$choices = clevie_layout_choices();
	$value   = get_post_meta( $post->ID, '_clevie_layout', true );
	$default = ( 'page' === $post->post_type )
		? get_theme_mod( 'clevie_layout_page', 'both' )
		: get_theme_mod( 'clevie_layout_post', 'both' );

	echo '<select name="clevie_layout" style="width:100%;">';
	printf(
		'<option value="">%s</option>',
		esc_html( sprintf( /* translators: %s: current default layout. */ __( 'Default (%s)', 'clevie-social' ), $choices[ $default ] ) )
	);
	foreach ( $choices as $key => $label ) {
		printf(
			'<option value="%1$s" %2$s>%3$s</option>',
			esc_attr( $key ),
			selected( $value, $key, false ),
			esc_html( $label )
		);
	}
	echo '</select>';

	echo '<p class="description">' . esc_html__( 'A sidebar only shows up when it holds widgets. On magazine pages the “Magazine layout” box controls the right sidebar.', 'clevie-social' ) . '</p>';
}

/**
 * Save the meta box.
 *
 * @param int $post_id Post ID.
 */
function clevie_layout_save( $post_id ) {
	if ( ! isset( $_POST['clevie_layout_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['clevie_layout_nonce'] ) ), 'clevie_layout_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$choices = clevie_layout_choices();
	$value   = isset( $_POST['clevie_layout'] ) ? sanitize_text_field( wp_unslash( $_POST['clevie_layout'] ) ) : '';

	if ( $value && isset( $choices[ $value ] ) ) {
		update_post_meta( $post_id, '_clevie_layout', $value );
	} else {
		delete_post_meta( $post_id, '_clevie_layout' );
	}
}
add_action( 'save_post', 'clevie_layout_save' );
