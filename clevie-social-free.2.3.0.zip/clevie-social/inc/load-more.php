<?php
/**
 * Loading the next posts in place, instead of paging.
 *
 * A community feed is a stream, and paging through a stream is the wrong shape:
 * page two is a different page, so the reader loses their place and their
 * scroll position, and on a phone the numbered links are a poor target.
 *
 * A button rather than loading on scroll. Endless loading takes the footer away
 * from the reader for good and leaves somebody using a keyboard with no way
 * past the feed, and it fetches things nobody asked for. The button loads when
 * asked and stops when ignored.
 *
 * Off by default, because it changes how a site behaves and the old paging is
 * a perfectly good answer.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is loading in place switched on?
 *
 * @return bool
 */
function clevie_loadmore_active() {
	return (bool) get_theme_mod( 'clevie_load_more', false );
}

/**
 * The choice in the Customizer.
 *
 * @param WP_Customize_Manager $wp_customize The manager.
 */
function clevie_loadmore_customize( $wp_customize ) {
	$wp_customize->add_setting( 'clevie_load_more', array(
		'default'           => false,
		'sanitize_callback' => 'wp_validate_boolean',
	) );

	$wp_customize->add_control( 'clevie_load_more', array(
		'label'       => __( 'Load more instead of page numbers', 'clevie-social' ),
		'description' => __( 'A feed is a stream, and page two loses the reader\'s place in it. A button that fetches the next posts in place keeps it. Loading on scroll is deliberately not offered: it takes the footer away for good and leaves anybody using a keyboard with no way past the feed.', 'clevie-social' ),
		'section'     => 'clevie_feed',
		'type'        => 'checkbox',
	) );
}
add_action( 'customize_register', 'clevie_loadmore_customize', 20 );

/**
 * The button, in place of the pagination.
 *
 * Printed only when there is another page to fetch.
 */
function clevie_loadmore_button() {
	global $wp_query;

	if ( ! clevie_loadmore_active() ) {
		return;
	}

	$pages = (int) $wp_query->max_num_pages;
	$page  = max( 1, (int) get_query_var( 'paged' ) );

	if ( $pages <= $page ) {
		return;
	}
	?>
	<div class="cv-loadmore" data-page="<?php echo absint( $page ); ?>" data-max="<?php echo absint( $pages ); ?>">
		<button type="button" class="cv-loadmore__button">
			<?php esc_html_e( 'Load more', 'clevie-social' ); ?>
		</button>

		<noscript>
			<?php
			// Without JavaScript the ordinary links are the only way on, so
			// they are here rather than nowhere.
			the_posts_pagination( array(
				'class'     => 'cv-pagination',
				'mid_size'  => 1,
				'prev_text' => __( 'Previous', 'clevie-social' ),
				'next_text' => __( 'Next', 'clevie-social' ),
			) );
			?>
		</noscript>
	</div>
	<?php
}

/**
 * Answer the request for the next page.
 *
 * The same query the page itself ran, one page further on, rendered with the
 * same template part. Rebuilding the markup separately is how a second feed
 * quietly drifts away from the first.
 */
function clevie_loadmore_fetch() {
	check_ajax_referer( 'clevie_loadmore', 'nonce' );

	$page  = max( 2, absint( $_POST['page'] ?? 2 ) );
	$query = isset( $_POST['query'] ) ? (array) json_decode( wp_unslash( $_POST['query'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

	// Whatever the browser sends back is treated as a request, not as an
	// instruction: only the keys a feed legitimately varies by are taken, and
	// each is cleaned. Passing the lot straight into WP_Query would let anybody
	// ask for drafts or somebody else's private posts.
	$safe = array(
		'post_type'      => 'post',
		'post_status'    => 'publish',
		'paged'          => $page,
		'posts_per_page' => (int) get_option( 'posts_per_page' ),
	);

	foreach ( array( 'cat', 'tag_id', 'author', 'year', 'monthnum' ) as $key ) {
		if ( isset( $query[ $key ] ) && '' !== $query[ $key ] ) {
			$safe[ $key ] = absint( $query[ $key ] );
		}
	}

	if ( isset( $query['s'] ) && '' !== $query['s'] ) {
		$safe['s'] = sanitize_text_field( $query['s'] );
	}

	if ( isset( $query['orderby'] ) && in_array( $query['orderby'], array( 'date', 'comment_count', 'rand', 'meta_value_num' ), true ) ) {
		$safe['orderby'] = $query['orderby'];

		if ( 'meta_value_num' === $safe['orderby'] && isset( $query['meta_key'] ) ) {
			// Only the plugin's own scores, never an arbitrary key.
			$allowed = array( 'clevie_score', 'clevie_hot', 'clevie_views' );

			if ( in_array( $query['meta_key'], $allowed, true ) ) {
				$safe['meta_key'] = $query['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery
			} else {
				unset( $safe['orderby'] );
			}
		}
	}

	$more = new WP_Query( $safe );

	if ( ! $more->have_posts() ) {
		wp_send_json_success( array( 'html' => '', 'done' => true ) );
	}

	ob_start();

	while ( $more->have_posts() ) {
		$more->the_post();

		get_template_part( 'template-parts/content', get_post_format() );
	}

	wp_reset_postdata();

	wp_send_json_success( array(
		'html' => ob_get_clean(),
		'done' => ( $page >= (int) $more->max_num_pages ),
	) );
}
add_action( 'wp_ajax_clevie_loadmore', 'clevie_loadmore_fetch' );
add_action( 'wp_ajax_nopriv_clevie_loadmore', 'clevie_loadmore_fetch' );

/**
 * The script, and what it needs to know.
 */
function clevie_loadmore_assets() {
	if ( ! clevie_loadmore_active() || is_singular() ) {
		return;
	}

	global $wp_query;

	wp_enqueue_script(
		'clevie-loadmore',
		get_template_directory_uri() . '/js/load-more.js',
		array(),
		CLEVIE_VERSION,
		true
	);

	wp_localize_script( 'clevie-loadmore', 'clevieLoadMore', array(
		'url'   => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'clevie_loadmore' ),
		'query' => wp_json_encode( array_intersect_key(
			$wp_query->query_vars,
			array_flip( array( 'cat', 'tag_id', 'author', 'year', 'monthnum', 's', 'orderby', 'meta_key' ) )
		) ),
		'i18n'  => array(
			'loading' => __( 'Loading…', 'clevie-social' ),
			'more'    => __( 'Load more', 'clevie-social' ),
			'failed'  => __( 'That did not work. Try again.', 'clevie-social' ),
		),
	) );
}
add_action( 'wp_enqueue_scripts', 'clevie_loadmore_assets', 20 );
