<?php
/**
 * Search engine output.
 *
 * The division of work: whatever an SEO plugin does well is left to it. What no
 * SEO plugin knows about this site is done here, always: that a topic is a
 * community, that a post carries votes, and that the sort links are the same
 * list in a different order.
 *
 * @package Clevie Social
 */

/**
 * Which SEO plugin is running, if any.
 *
 * @return string 'yoast', 'rankmath', 'aioseo', 'seopress', 'slim' or ''.
 */
function clevie_seo_plugin() {
	if ( defined( 'WPSEO_VERSION' ) ) {
		return 'yoast';
	}

	if ( defined( 'RANK_MATH_VERSION' ) ) {
		return 'rankmath';
	}

	if ( defined( 'AIOSEO_VERSION' ) ) {
		return 'aioseo';
	}

	if ( defined( 'SEOPRESS_VERSION' ) ) {
		return 'seopress';
	}

	if ( defined( 'SLIM_SEO_VERSION' ) || function_exists( 'slim_seo' ) ) {
		return 'slim';
	}

	return '';
}

/**
 * Should the theme handle the ordinary tags itself?
 *
 * @return bool
 */
function clevie_seo_handles_basics() {
	return ( '' === clevie_seo_plugin() && get_theme_mod( 'clevie_seo_basics', true ) );
}

/**
 * The description of the current view, for the meta tag and for sharing.
 *
 * @return string
 */
function clevie_seo_description() {
	if ( is_singular() ) {
		$post = get_queried_object();

		if ( has_excerpt( $post ) ) {
			return wp_strip_all_tags( get_the_excerpt( $post ) );
		}

		return wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 30, '' );
	}

	if ( is_category() || is_tag() ) {
		$term = get_queried_object();

		if ( ! empty( $term->description ) ) {
			return wp_strip_all_tags( $term->description );
		}

		return sprintf(
			/* translators: 1: name of the topic, 2: name of the site. */
			__( 'Posts and discussions in %1$s on %2$s.', 'clevie-social' ),
			$term->name,
			get_bloginfo( 'name' )
		);
	}

	if ( is_author() ) {
		$bio = get_the_author_meta( 'description', (int) get_queried_object_id() );

		if ( $bio ) {
			return wp_strip_all_tags( $bio );
		}
	}

	return get_bloginfo( 'description' );
}

/**
 * The picture that represents the current view.
 *
 * @return string
 */
function clevie_seo_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		$url = get_the_post_thumbnail_url( get_queried_object_id(), 'large' );

		if ( $url ) {
			return $url;
		}
	}

	if ( is_category() && function_exists( 'clevie_topic_header_image' ) ) {
		$url = clevie_topic_header_image( (int) get_queried_object_id(), 'large' );

		if ( $url ) {
			return $url;
		}
	}

	$logo = get_theme_mod( 'custom_logo' );

	if ( $logo ) {
		$image = wp_get_attachment_image_src( $logo, 'full' );

		if ( $image ) {
			return $image[0];
		}
	}

	return '';
}

/**
 * Description and the sharing tags, only where nothing else provides them.
 */
function clevie_seo_meta() {
	if ( ! clevie_seo_handles_basics() ) {
		return;
	}

	$description = clevie_seo_description();
	$image       = clevie_seo_image();
	$title       = wp_get_document_title();

	if ( $description ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( wp_html_excerpt( $description, 160, '…' ) ) );
	}

	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	printf( '<meta property="og:type" content="%s">' . "\n", is_singular( 'post' ) ? 'article' : 'website' );
	printf( '<meta property="og:url" content="%s">' . "\n", esc_url( clevie_seo_current_url() ) );

	if ( $description ) {
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( wp_html_excerpt( $description, 200, '…' ) ) );
	}

	if ( $image ) {
		printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $image ) );
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	} else {
		echo '<meta name="twitter:card" content="summary">' . "\n";
	}

	if ( is_singular( 'post' ) ) {
		printf( '<meta property="article:published_time" content="%s">' . "\n", esc_attr( get_the_date( 'c' ) ) );
		printf( '<meta property="article:modified_time" content="%s">' . "\n", esc_attr( get_the_modified_date( 'c' ) ) );

		$cats = get_the_category();

		if ( ! empty( $cats ) ) {
			printf( '<meta property="article:section" content="%s">' . "\n", esc_attr( $cats[0]->name ) );
		}
	}
}
add_action( 'wp_head', 'clevie_seo_meta', 5 );

/**
 * The address of the page being looked at, without the parameters that only
 * change the order.
 *
 * @param bool $clean Drop sort and feed parameters.
 * @return string
 */
function clevie_seo_current_url( $clean = true ) {
	if ( is_singular() ) {
		return get_permalink();
	}

	if ( is_category() || is_tag() || is_tax() ) {
		$link = get_term_link( get_queried_object() );

		return is_wp_error( $link ) ? home_url( '/' ) : $link;
	}

	if ( is_author() ) {
		return get_author_posts_url( (int) get_queried_object_id() );
	}

	if ( is_home() || is_front_page() ) {
		return home_url( '/' );
	}

	$url = home_url( add_query_arg( array() ) );

	return $clean ? remove_query_arg( array( 'sort', 'rdfeed' ), $url ) : $url;
}

/**
 * Sorted views are the same list in another order. Without a canonical they
 * look like three copies of the front page to a search engine.
 *
 * This runs whatever else is installed, because no SEO plugin knows these
 * parameters.
 */
function clevie_seo_canonical_sorted() {
	// On a single post WordPress has its own canonical and it is the right one.
	if ( is_singular() ) {
		return;
	}

	if ( ! isset( $_GET['sort'] ) && ! isset( $_GET['rdfeed'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}

	// WordPress puts out no canonical on an archive, so nothing has to be taken
	// away here: this one is added, not swapped. Sorted views also carry
	// noindex, which is the part that actually keeps them out of the index.
	printf( '<link rel="canonical" href="%s">' . "\n", esc_url( clevie_seo_current_url() ) );
}
add_action( 'wp_head', 'clevie_seo_canonical_sorted', 1 );

/**
 * Take the canonical of an SEO plugin off a sorted view as well.
 *
 * @param string $url Canonical.
 * @return string
 */
function clevie_seo_filter_canonical( $url ) {
	if ( is_singular() ) {
		return $url;
	}

	if ( isset( $_GET['sort'] ) || isset( $_GET['rdfeed'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return clevie_seo_current_url();
	}

	return $url;
}
add_filter( 'wpseo_canonical', 'clevie_seo_filter_canonical' );
add_filter( 'rank_math/frontend/canonical', 'clevie_seo_filter_canonical' );
add_filter( 'aioseo_canonical_url', 'clevie_seo_filter_canonical' );

/**
 * Pages that are of no use in a search result.
 *
 * @param array $robots Robots directives.
 * @return array
 */
function clevie_seo_robots( $robots ) {
	$hide = false;

	// A sorted view is the same list in another order.
	if ( ! is_singular() && ( isset( $_GET['sort'] ) || isset( $_GET['rdfeed'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$hide = true;
	}

	// Profiles, the post form and the moderation page: useful on the site,
	// pointless in an index.
	if ( is_author() && get_theme_mod( 'clevie_seo_noindex_authors', true ) ) {
		$hide = true;
	}

	if ( is_page() && function_exists( 'clevie_page_map' ) ) {
		$settings = (array) get_option( 'clevie_settings', array() );
		$ids      = array();

		foreach ( array_keys( clevie_page_map() ) as $key ) {
			if ( ! empty( $settings[ $key ] ) ) {
				$ids[] = (int) $settings[ $key ];
			}
		}

		if ( in_array( (int) get_queried_object_id(), $ids, true ) ) {
			$hide = true;
		}
	}

	if ( $hide ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}

	return $robots;
}
add_filter( 'wp_robots', 'clevie_seo_robots' );

/**
 * The structured data. A post in a community is a DiscussionForumPosting, which
 * search engines read differently from an article: votes and replies count.
 *
 * No SEO plugin can produce this, so it goes out regardless of what is running.
 */
function clevie_seo_schema() {
	if ( ! get_theme_mod( 'clevie_seo_schema', true ) ) {
		return;
	}

	$data = array();

	if ( is_singular( 'post' ) ) {
		$data = clevie_seo_schema_post();
	} elseif ( is_category() ) {
		$data = clevie_seo_schema_topic();
	}

	if ( ! $data ) {
		return;
	}

	printf(
		'<script type="application/ld+json">%s</script>' . "\n",
		wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}
add_action( 'wp_head', 'clevie_seo_schema', 20 );

/**
 * Structured data for a single post.
 *
 * @return array
 */
function clevie_seo_schema_post() {
	$post_id = get_the_ID();

	$data = array(
		'@context'      => 'https://schema.org',
		'@type'         => 'DiscussionForumPosting',
		'@id'           => get_permalink(),
		'url'           => get_permalink(),
		'headline'      => wp_strip_all_tags( get_the_title() ),
		'datePublished' => get_the_date( 'c' ),
		'dateModified'  => get_the_modified_date( 'c' ),
		'author'        => array(
			'@type' => 'Person',
			'name'  => get_the_author(),
			'url'   => get_author_posts_url( (int) get_the_author_meta( 'ID' ) ),
		),
	);

	$text = wp_strip_all_tags( strip_shortcodes( get_the_content() ) );

	if ( $text ) {
		$data['text'] = wp_html_excerpt( $text, 500, '…' );
	}

	if ( has_post_thumbnail() ) {
		$data['image'] = get_the_post_thumbnail_url( $post_id, 'large' );
	}

	$cats = get_the_category();

	if ( ! empty( $cats ) ) {
		$data['isPartOf'] = array(
			'@type' => 'DiscussionForumPosting',
			'name'  => $cats[0]->name,
			'url'   => get_category_link( $cats[0]->term_id ),
		);
	}

	// Votes, if the plugin is there. This is what tells a search engine that a
	// post is worth something to the people who read it.
	if ( function_exists( 'clevie_score' ) ) {
		$score = (int) apply_filters( 'clevie_post_score', 0, $post_id );

		if ( $score ) {
			$data['interactionStatistic'][] = array(
				'@type'                => 'InteractionCounter',
				'interactionType'      => 'https://schema.org/LikeAction',
				'userInteractionCount' => max( 0, $score ),
			);
		}
	}

	$comments = (int) get_comments_number();

	if ( $comments ) {
		$data['interactionStatistic'][] = array(
			'@type'                => 'InteractionCounter',
			'interactionType'      => 'https://schema.org/CommentAction',
			'userInteractionCount' => $comments,
		);

		$data['commentCount'] = $comments;

		// Up to five replies, which is what a rich result shows at most.
		$list = get_comments( array(
			'post_id' => $post_id,
			'status'  => 'approve',
			'number'  => 5,
			'orderby' => 'comment_date_gmt',
			'order'   => 'ASC',
		) );

		foreach ( $list as $comment ) {
			$data['comment'][] = array(
				'@type'         => 'Comment',
				'text'          => wp_html_excerpt( wp_strip_all_tags( $comment->comment_content ), 300, '…' ),
				'datePublished' => gmdate( 'c', strtotime( $comment->comment_date_gmt ) ),
				'author'        => array(
					'@type' => 'Person',
					'name'  => $comment->comment_author,
				),
			);
		}
	}

	return $data;
}

/**
 * Structured data for a topic: the breadcrumb plus what the topic is.
 *
 * @return array
 */
function clevie_seo_schema_topic() {
	$term = get_queried_object();

	if ( ! $term || is_wp_error( $term ) ) {
		return array();
	}

	$crumbs = array(
		array(
			'@type'    => 'ListItem',
			'position' => 1,
			'name'     => get_bloginfo( 'name' ),
			'item'     => home_url( '/' ),
		),
	);

	$position = 2;
	$parents  = array();
	$parent   = (int) $term->parent;

	while ( $parent ) {
		$up = get_term( $parent, 'category' );

		if ( ! $up || is_wp_error( $up ) ) {
			break;
		}

		array_unshift( $parents, $up );
		$parent = (int) $up->parent;
	}

	foreach ( $parents as $up ) {
		$crumbs[] = array(
			'@type'    => 'ListItem',
			'position' => $position++,
			'name'     => $up->name,
			'item'     => get_category_link( $up->term_id ),
		);
	}

	$crumbs[] = array(
		'@type'    => 'ListItem',
		'position' => $position,
		'name'     => $term->name,
		'item'     => get_category_link( $term->term_id ),
	);

	return array(
		'@context'        => 'https://schema.org',
		'@type'           => 'CollectionPage',
		'@id'             => get_category_link( $term->term_id ),
		'name'            => $term->name,
		'description'     => $term->description ? wp_strip_all_tags( $term->description ) : clevie_seo_description(),
		'breadcrumb'      => array(
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $crumbs,
		),
	);
}

/**
 * The posts loaded into the stream under an article live at their own address.
 * Telling search engines where they belong keeps them from counting as a copy.
 *
 * @param string $class Classes.
 * @return string
 */
function clevie_seo_stream_notice() {
	if ( ! is_singular( 'post' ) ) {
		return;
	}

	if ( 'next' !== get_theme_mod( 'clevie_after_comments', 'related' ) ) {
		return;
	}

	echo "\n<!-- The posts below the comments are shown in full for readers and each live at their own address. -->\n";
}
add_action( 'wp_footer', 'clevie_seo_stream_notice', 1 );

/**
 * The settings.
 *
 * @param WP_Customize_Manager $wp_customize Customizer.
 */
function clevie_seo_customizer( $wp_customize ) {
	$wp_customize->add_section( 'clevie_seo', array(
		'title'       => __( 'Search engines', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'priority'    => 90,
		'description' => clevie_seo_plugin()
			? sprintf(
				/* translators: %s: name of the SEO plugin. */
				__( '%s is running and takes care of titles, descriptions and the sitemap. The theme adds what it cannot know: the structured data of a community and the canonical for the sort links.', 'clevie-social' ),
				clevie_seo_plugin_name()
			)
			: __( 'No SEO plugin was found, so the theme puts out the description and the sharing tags itself. Installing one later switches that off on its own.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_seo_basics', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_seo_basics', array(
		'label'       => __( 'Description and sharing tags', 'clevie-social' ),
		'description' => __( 'Meta description, Open Graph and Twitter cards. Ignored while an SEO plugin is running.', 'clevie-social' ),
		'section'     => 'clevie_seo',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_seo_schema', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_seo_schema', array(
		'label'       => __( 'Structured data for the community', 'clevie-social' ),
		'description' => __( 'Marks a post as a forum discussion with its votes and replies, and a topic with its breadcrumb.', 'clevie-social' ),
		'section'     => 'clevie_seo',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'clevie_seo_noindex_authors', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_seo_noindex_authors', array(
		'label'       => __( 'Keep author pages out of search results', 'clevie-social' ),
		'description' => __( 'Author archives repeat posts that already have their own page. Links on them are still followed.', 'clevie-social' ),
		'section'     => 'clevie_seo',
		'type'        => 'checkbox',
	) );
}
add_action( 'customize_register', 'clevie_seo_customizer' );

/**
 * The name of the SEO plugin, for the notice.
 *
 * @return string
 */
function clevie_seo_plugin_name() {
	$names = array(
		'yoast'    => 'Yoast SEO',
		'rankmath' => 'Rank Math',
		'aioseo'   => 'All in One SEO',
		'seopress' => 'SEOPress',
		'slim'     => 'Slim SEO',
	);

	$slug = clevie_seo_plugin();

	return isset( $names[ $slug ] ) ? $names[ $slug ] : '';
}
