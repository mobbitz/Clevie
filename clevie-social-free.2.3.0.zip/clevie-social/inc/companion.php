<?php
/**
 * Point people at the Clevie Community plugin.
 *
 * The theme shows posts and comments on its own. Votes, front-end posting,
 * topics, member profiles and the rest come from the plugin, which lives in the
 * WordPress plugin directory.
 *
 * That last part is what makes this file allowed to exist in the free build.
 * A theme in the directory may recommend a plugin, but only one that is in the
 * directory itself, and it may not ship or fetch one from anywhere else. So
 * everything here goes through the ordinary WordPress installer against
 * wordpress.org: no package of ours, no download address of ours.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin being recommended.
 */
const CLEVIE_COMPANION_SLUG = 'clevie-community';
const CLEVIE_COMPANION_FILE = 'clevie-community/clevie-community.php';

/**
 * Is it running?
 *
 * @return bool
 */
function clevie_companion_active() {
	return function_exists( 'clevie_community_can' );
}

/**
 * Is it on disk but switched off?
 *
 * @return bool
 */
function clevie_companion_installed() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$plugins = get_plugins();

	return isset( $plugins[ CLEVIE_COMPANION_FILE ] );
}

/**
 * Is the plugin actually available in the directory yet?
 *
 * Everything here links to the wordpress.org installer, which can only fetch
 * what the directory has. Before the plugin is published, or while a review is
 * still running, that installer answers "Plugin not found" — and a button that
 * leads to an error is worse than no button. The answer is cached for a day so
 * this costs one request, not one per page load.
 *
 * @return bool
 */
function clevie_companion_in_directory() {
	$known = get_site_transient( 'clevie_companion_available' );

	if ( false !== $known ) {
		return ( 'yes' === $known );
	}

	if ( ! function_exists( 'plugins_api' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
	}

	$answer = plugins_api( 'plugin_information', array(
		'slug'   => CLEVIE_COMPANION_SLUG,
		'fields' => array( 'sections' => false, 'short_description' => false ),
	) );

	$found = ! is_wp_error( $answer ) && ! empty( $answer->slug );

	// A miss is remembered for less long than a hit: once the plugin goes live
	// the suggestion should start working within hours, not tomorrow.
	set_site_transient(
		'clevie_companion_available',
		$found ? 'yes' : 'no',
		$found ? DAY_IN_SECONDS : 6 * HOUR_IN_SECONDS
	);

	return $found;
}

/**
 * The suggestion.
 *
 * Only on the dashboard and the theme screens. A notice on every page of the
 * admin is how people learn to dismiss things without reading them, and it can
 * always be put away for good.
 */
function clevie_companion_notice() {
	if ( clevie_companion_active() || ! current_user_can( 'install_plugins' ) ) {
		return;
	}

	if ( get_user_meta( get_current_user_id(), '_clevie_companion_dismissed', true ) ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

	if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'themes', 'appearance_page_clevie-social' ), true ) ) {
		return;
	}

	$installed = clevie_companion_installed();

	// Already on disk: it only needs switching on, and the directory does not
	// come into it. Not on disk: only worth offering if it can be fetched.
	if ( ! $installed && ! clevie_companion_in_directory() ) {
		return;
	}

	// Both of these are core screens doing the work, with core's own nonces and
	// capability checks. The theme only links to them.
	if ( $installed ) {
		$url   = wp_nonce_url(
			self_admin_url( 'plugins.php?action=activate&plugin=' . rawurlencode( CLEVIE_COMPANION_FILE ) ),
			'activate-plugin_' . CLEVIE_COMPANION_FILE
		);
		$label = __( 'Activate Clevie Community', 'clevie-social' );
	} else {
		$url   = wp_nonce_url(
			self_admin_url( 'update.php?action=install-plugin&plugin=' . CLEVIE_COMPANION_SLUG ),
			'install-plugin_' . CLEVIE_COMPANION_SLUG
		);
		$label = __( 'Install Clevie Community', 'clevie-social' );
	}

	$details = self_admin_url(
		'plugin-install.php?tab=plugin-information&plugin=' . CLEVIE_COMPANION_SLUG . '&TB_iframe=true&width=772&height=600'
	);
	?>
	<div class="notice notice-info">
		<p>
			<strong><?php esc_html_e( 'Clevie Social works best with Clevie Community', 'clevie-social' ); ?></strong>
		</p>
		<p>
			<?php esc_html_e( 'The free plugin adds votes, posting from the front end, topics and member profiles. The theme runs without it, but most of what it was built for lives there.', 'clevie-social' ); ?>
		</p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?></a>
			<a class="button thickbox open-plugin-details-modal" href="<?php echo esc_url( $details ); ?>"><?php esc_html_e( 'Details', 'clevie-social' ); ?></a>

			<a class="button-link" href="<?php echo esc_url( wp_nonce_url( admin_url( 'themes.php?clevie_companion_dismiss=1' ), 'clevie_companion_dismiss' ) ); ?>" style="margin-left:8px;">
				<?php esc_html_e( 'No thanks', 'clevie-social' ); ?>
			</a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'clevie_companion_notice' );

/**
 * Put the suggestion away for good, for this person.
 */
function clevie_companion_dismiss() {
	if ( ! isset( $_GET['clevie_companion_dismiss'] ) ) {
		return;
	}

	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'clevie_companion_dismiss' ) ) {
		return;
	}

	update_user_meta( get_current_user_id(), '_clevie_companion_dismissed', 1 );

	wp_safe_redirect( admin_url( 'themes.php' ) );
	exit;
}
add_action( 'load-themes.php', 'clevie_companion_dismiss' );

/**
 * The details window needs core's thickbox, which is not loaded on every
 * screen the notice can appear on.
 *
 * @param string $hook Current screen.
 */
function clevie_companion_assets( $hook ) {
	if ( ! in_array( $hook, array( 'index.php', 'themes.php' ), true ) ) {
		return;
	}

	if ( clevie_companion_active() || ! current_user_can( 'install_plugins' ) ) {
		return;
	}

	add_thickbox();
}
add_action( 'admin_enqueue_scripts', 'clevie_companion_assets' );
