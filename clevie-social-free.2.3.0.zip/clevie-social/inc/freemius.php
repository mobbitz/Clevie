<?php
/**
 * Clevie Social Freemius helpers.
 *
 * The Freemius SDK itself is initialized in functions.php using the official
 * theme integration snippet. This file only contains Clevie's feature gates
 * and upgrade helper functions.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is a paid licence in place?
 *
 * Freemius decides this, and when it cannot be asked the answer is no.
 *
 * This used to return true when the SDK was unavailable, on the reasoning that
 * an installed site should keep working. The effect was the opposite of what
 * was intended: removing the vendor directory, or defining clevie_fs() ahead of
 * the theme, turned every paid feature on. There is no hiccup to protect
 * against either, because the licence is read from the database and not over
 * the network, so an SDK that will not answer means something is broken or
 * someone is having a go.
 *
 * Note for the paid build: can_use_premium_code__premium_only() is
 * is_premium() && can_use_premium_code(), and is_premium comes from the
 * 'is_premium' flag passed to fs_dynamic_init. It is false in this free
 * package, which is correct: the paid features live in the premium build.
 *
 * @return bool
 */
function clevie_is_premium() {
	$fs = function_exists( 'clevie_fs' ) ? clevie_fs() : null;

	if ( ! $fs || ! method_exists( $fs, 'can_use_premium_code__premium_only' ) ) {
		return false;
	}

	$premium = (bool) $fs->can_use_premium_code__premium_only();

	// The filter may take the paid features away, for testing what a free
	// visitor sees, but it cannot hand them out. Otherwise a single line in a
	// must-use plugin would be the whole licence check.
	return $premium && (bool) apply_filters( 'clevie_is_premium', $premium );
}

/**
 * Is a single feature available?
 *
 * @param string $feature Feature key.
 * @return bool
 */
function clevie_can( $feature ) {
	$premium = apply_filters( 'clevie_premium_features', array(
		'magazine',
		'typography',
		'stream',
		'dark_colors',
		'seo_schema',
		'fonts_all',
	) );

	if ( ! in_array( $feature, $premium, true ) ) {
		return true;
	}

	return clevie_is_premium();
}

/**
 * A short line in the Customizer where a section is paid only.
 *
 * @param string $feature Feature key.
 * @return string
 */
function clevie_upgrade_notice( $feature ) {
	if ( clevie_can( $feature ) ) {
		return '';
	}

	$fs  = function_exists( 'clevie_fs' ) ? clevie_fs() : null;
	$url = ( $fs && method_exists( $fs, 'get_upgrade_url' ) ) ? (string) $fs->get_upgrade_url() : '';

	if ( ! $url ) {
		/** This filter is documented at the end of this function. */
		return apply_filters( 'clevie_upgrade_notice', sprintf(
			'<p class="clevie-upgrade">%1$s</p>',
			esc_html__( 'This is part of the paid edition.', 'clevie-social' )
		), $feature );
	}

	/**
	 * Filters the prompt shown in place of a paid feature.
	 *
	 * Used to add a way in for somebody who already holds a key, which the SDK
	 * does not offer in the free version.
	 *
	 * @param string $notice  The prompt.
	 * @param string $feature Feature key.
	 */
	return apply_filters( 'clevie_upgrade_notice', sprintf(
		'<p class="clevie-upgrade">%1$s <a href="%2$s" target="_blank" rel="noopener">%3$s</a></p>',
		esc_html__( 'This is part of the paid edition.', 'clevie-social' ),
		esc_url( $url ),
		esc_html__( 'See the plans', 'clevie-social' )
	), $feature );
}

/**
 * Backwards-compatible short helper name.
 *
 * @return Freemius|null
 */
function cs_fs() {
	return clevie_fs();
}
