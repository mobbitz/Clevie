<?php
/**
 * A way in for somebody who already has a licence.
 *
 * Freemius does not offer licence activation in the free version of a freemium
 * product. Its own condition says so plainly:
 *
 *     if ( $this->has_premium_version() && ! $this->is_premium() && ! $license ) {
 *         return;
 *     }
 *
 * The reasoning is that a licence goes with the paid build, so activate it
 * there. That works for somebody who just bought, because they are handed the
 * download in the same breath. It does not work for a licence that was given
 * away: the recipient installs the free theme, has a key in their hand, and the
 * only thing on offer is a pricing page.
 *
 * So the link is put back. It points at the opt-in screen, which does take a
 * licence key — the same screen that appears when the theme is activated for
 * the first time, only reachable again afterwards.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Where somebody can hand over a key.
 *
 * @return string Empty when there is nothing to activate against.
 */
function clevie_license_entry_url() {
	if ( ! function_exists( 'clevie_fs' ) ) {
		return '';
	}

	$fs = clevie_fs();

	if ( ! $fs || ! method_exists( $fs, 'get_activation_url' ) ) {
		return '';
	}

	return (string) $fs->get_activation_url();
}

/**
 * Should the link be shown at all?
 *
 * Not to somebody who already has a working licence, and not on a site whose
 * theme cannot be licensed in the first place.
 *
 * @return bool
 */
function clevie_license_entry_needed() {
	if ( ! current_user_can( 'switch_themes' ) ) {
		return false;
	}

	if ( function_exists( 'clevie_is_premium' ) && clevie_is_premium() ) {
		return false;
	}

	return (bool) clevie_license_entry_url();
}

/**
 * The notice on the theme screens.
 */
function clevie_license_entry_notice() {
	if ( ! clevie_license_entry_needed() ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

	if ( ! $screen || ! in_array( $screen->id, array( 'themes', 'appearance_page_clevie-social' ), true ) ) {
		return;
	}

	if ( get_user_meta( get_current_user_id(), '_clevie_license_notice_off', true ) ) {
		return;
	}
	?>
	<div class="notice notice-info">
		<p>
			<?php esc_html_e( 'Already have a licence key for Clevie Social — bought, or given to you? Enter it here and the paid features are unlocked.', 'clevie-social' ); ?>
		</p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( clevie_license_entry_url() ); ?>">
				<?php esc_html_e( 'I already have a licence', 'clevie-social' ); ?>
			</a>

			<a class="button-link" style="margin-left:8px;" href="<?php echo esc_url( wp_nonce_url( admin_url( 'themes.php?clevie_license_notice_off=1' ), 'clevie_license_notice_off' ) ); ?>">
				<?php esc_html_e( 'Hide this', 'clevie-social' ); ?>
			</a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'clevie_license_entry_notice' );

/**
 * Put the notice away.
 */
function clevie_license_entry_dismiss() {
	if ( ! isset( $_GET['clevie_license_notice_off'] ) ) {
		return;
	}

	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'clevie_license_notice_off' ) ) {
		return;
	}

	update_user_meta( get_current_user_id(), '_clevie_license_notice_off', 1 );

	wp_safe_redirect( admin_url( 'themes.php' ) );
	exit;
}
add_action( 'load-themes.php', 'clevie_license_entry_dismiss' );

/**
 * The same link under the upgrade prompt in the Customizer, where somebody who
 * went looking for the paid features actually is.
 *
 * @param string $notice The upgrade prompt.
 * @return string
 */
function clevie_license_entry_in_notice( $notice ) {
	if ( ! clevie_license_entry_needed() ) {
		return $notice;
	}

	return $notice . sprintf(
		'<p class="clevie-have-license"><a href="%1$s">%2$s</a></p>',
		esc_url( clevie_license_entry_url() ),
		esc_html__( 'I already have a licence', 'clevie-social' )
	);
}
add_filter( 'clevie_upgrade_notice', 'clevie_license_entry_in_notice' );
