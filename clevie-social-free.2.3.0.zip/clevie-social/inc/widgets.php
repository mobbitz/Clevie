<?php
/**
 * Custom widgets shipped with the theme.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Posts with thumbnails.
 */
class Clevie_Posts_Widget extends WP_Widget {

	/**
	 * Register the widget.
	 */
	public function __construct() {
		parent::__construct(
			'clevie_posts',
			__( 'Clevie: Posts', 'clevie-social' ),
			array( 'description' => __( 'Latest, most commented or random posts with a thumbnail.', 'clevie-social' ) )
		);
	}

	/**
	 * Front end output.
	 *
	 * @param array $args     Sidebar arguments.
	 * @param array $instance Widget settings.
	 */
	public function widget( $args, $instance ) {
		$title = isset( $instance['title'] ) ? (string) $instance['title'] : __( 'Posts', 'clevie-social' );
		$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$order  = isset( $instance['order'] ) ? $instance['order'] : 'recent';
		$thumb  = ! empty( $instance['thumb'] );
		$meta   = ! empty( $instance['meta'] );

		$query_args = array(
			'posts_per_page'      => max( 1, $number ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);

		if ( 'comments' === $order ) {
			$query_args['orderby'] = 'comment_count';
		} elseif ( 'random' === $order ) {
			$query_args['orderby'] = 'rand';
		}

		$posts = new WP_Query( $query_args );

		if ( ! $posts->have_posts() ) {
			return;
		}

		echo wp_kses_post( $args['before_widget'] );

		if ( $title ) {
			echo wp_kses_post( $args['before_title'] . esc_html( $title ) . $args['after_title'] );
		}

		echo '<div class="cv-card__body"><ul class="cv-widget-posts">';

		while ( $posts->have_posts() ) {
			$posts->the_post();
			echo '<li class="cv-widget-posts__item">';

			if ( $thumb && has_post_thumbnail() ) {
				printf(
					'<a class="cv-widget-posts__thumb" href="%1$s" tabindex="-1" aria-hidden="true">%2$s</a>',
					esc_url( get_permalink() ),
					get_the_post_thumbnail( get_the_ID(), 'thumbnail', array( 'loading' => 'lazy' ) )
				);
			}

			echo '<span class="cv-widget-posts__text">';
			printf( '<a href="%1$s">%2$s</a>', esc_url( get_permalink() ), esc_html( get_the_title() ) );

			if ( $meta ) {
				printf(
					'<span class="cv-widget-posts__meta">%1$s &middot; %2$s</span>',
					esc_html( get_the_date() ),
					esc_html( sprintf( /* translators: %s: number of comments. */ _n( '%s comment', '%s comments', (int) get_comments_number(), 'clevie-social' ), number_format_i18n( get_comments_number() ) ) )
				);
			}

			echo '</span></li>';
		}

		wp_reset_postdata();

		echo '</ul></div>';
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Settings form.
	 *
	 * @param array $instance Widget settings.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? (string) $instance['title'] : __( 'Posts', 'clevie-social' );
		$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$order  = isset( $instance['order'] ) ? $instance['order'] : 'recent';
		$thumb  = isset( $instance['thumb'] ) ? (bool) $instance['thumb'] : true;
		$meta   = isset( $instance['meta'] ) ? (bool) $instance['meta'] : true;
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'clevie-social' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts:', 'clevie-social' ); ?></label>
			<input class="tiny-text" type="number" min="1" max="20" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" value="<?php echo esc_attr( $number ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>"><?php esc_html_e( 'Sort by:', 'clevie-social' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>">
				<option value="recent" <?php selected( $order, 'recent' ); ?>><?php esc_html_e( 'Latest', 'clevie-social' ); ?></option>
				<option value="comments" <?php selected( $order, 'comments' ); ?>><?php esc_html_e( 'Most comments', 'clevie-social' ); ?></option>
				<option value="random" <?php selected( $order, 'random' ); ?>><?php esc_html_e( 'Random', 'clevie-social' ); ?></option>
			</select>
		</p>
		<p>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'thumb' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'thumb' ) ); ?>" <?php checked( $thumb ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'thumb' ) ); ?>"><?php esc_html_e( 'Show thumbnails', 'clevie-social' ); ?></label>
		</p>
		<p>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'meta' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'meta' ) ); ?>" <?php checked( $meta ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'meta' ) ); ?>"><?php esc_html_e( 'Show date and comment count', 'clevie-social' ); ?></label>
		</p>
		<?php
	}

	/**
	 * Save the settings.
	 *
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return array(
			'title'  => sanitize_text_field( $new_instance['title'] ),
			'number' => absint( $new_instance['number'] ),
			'order'  => in_array( $new_instance['order'], array( 'recent', 'comments', 'random' ), true ) ? $new_instance['order'] : 'recent',
			'thumb'  => ! empty( $new_instance['thumb'] ),
			'meta'   => ! empty( $new_instance['meta'] ),
		);
	}
}

/**
 * About box, the community info card.
 */
class Clevie_About_Widget extends WP_Widget {

	/**
	 * Register the widget.
	 */
	public function __construct() {
		parent::__construct(
			'clevie_about',
			__( 'Clevie: About box', 'clevie-social' ),
			array( 'description' => __( 'Image, text and a button, for a community box in the sidebar.', 'clevie-social' ) )
		);
	}

	/**
	 * Front end output.
	 *
	 * @param array $args     Sidebar arguments.
	 * @param array $instance Widget settings.
	 */
	public function widget( $args, $instance ) {
		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title'] );
		}

		echo '<div class="cv-card__body cv-about">';

		if ( ! empty( $instance['image'] ) ) {
			printf( '<img class="cv-about__image" src="%s" alt="" loading="lazy">', esc_url( $instance['image'] ) );
		}

		if ( ! empty( $instance['text'] ) ) {
			printf( '<p class="cv-about__text">%s</p>', esc_html( $instance['text'] ) );
		}

		if ( ! empty( $instance['button_text'] ) ) {
			printf(
				'<a class="cv-btn cv-about__button" href="%1$s">%2$s</a>',
				esc_url( ! empty( $instance['button_url'] ) ? $instance['button_url'] : home_url( '/' ) ),
				esc_html( $instance['button_text'] )
			);
		}

		echo '</div>';
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Settings form.
	 *
	 * @param array $instance Widget settings.
	 */
	public function form( $instance ) {
		$fields = array(
			'title'       => __( 'Title:', 'clevie-social' ),
			'image'       => __( 'Image URL:', 'clevie-social' ),
			'text'        => __( 'Text:', 'clevie-social' ),
			'button_text' => __( 'Button label:', 'clevie-social' ),
			'button_url'  => __( 'Button link:', 'clevie-social' ),
		);

		foreach ( $fields as $key => $label ) {
			$value = isset( $instance[ $key ] ) ? $instance[ $key ] : '';
			printf(
				'<p><label for="%1$s">%2$s</label>',
				esc_attr( $this->get_field_id( $key ) ),
				esc_html( $label )
			);

			if ( 'text' === $key ) {
				printf(
					'<textarea class="widefat" rows="4" id="%1$s" name="%2$s">%3$s</textarea></p>',
					esc_attr( $this->get_field_id( $key ) ),
					esc_attr( $this->get_field_name( $key ) ),
					esc_textarea( $value )
				);
			} else {
				printf(
					'<input class="widefat" type="text" id="%1$s" name="%2$s" value="%3$s"></p>',
					esc_attr( $this->get_field_id( $key ) ),
					esc_attr( $this->get_field_name( $key ) ),
					esc_attr( $value )
				);
			}
		}

		echo '<p class="description">' . esc_html__( 'Upload the image in the media library and paste its URL here.', 'clevie-social' ) . '</p>';
	}

	/**
	 * Save the settings.
	 *
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return array(
			'title'       => sanitize_text_field( $new_instance['title'] ),
			'image'       => esc_url_raw( $new_instance['image'] ),
			'text'        => sanitize_textarea_field( $new_instance['text'] ),
			'button_text' => sanitize_text_field( $new_instance['button_text'] ),
			'button_url'  => esc_url_raw( $new_instance['button_url'] ),
		);
	}
}

/**
 * Social links.
 */
class Clevie_Social_Widget extends WP_Widget {

	/**
	 * Register the widget.
	 */
	public function __construct() {
		parent::__construct(
			'clevie_social',
			__( 'Clevie: Social links', 'clevie-social' ),
			array( 'description' => __( 'A row of links to your profiles, one per line.', 'clevie-social' ) )
		);
	}

	/**
	 * Brand colors for known networks.
	 *
	 * @return array
	 */
	public static function brands() {
		return array(
			'x'         => '#000000',
			'twitter'   => '#1d9bf0',
			'facebook'  => '#1877f2',
			'instagram' => '#c13584',
			'youtube'   => '#ff0000',
			'linkedin'  => '#0a66c2',
			'github'    => '#24292f',
			'mastodon'  => '#6364ff',
			'discord'   => '#5865f2',
			'orange'    => '#ff4500',
			'tiktok'    => '#010101',
			'twitch'    => '#9146ff',
			'pinterest' => '#e60023',
			'threads'   => '#000000',
			'bluesky'   => '#0085ff',
			'telegram'  => '#26a5e4',
			'whatsapp'  => '#25d366',
			'rss'       => '#f26522',
		);
	}

	/**
	 * Front end output.
	 *
	 * @param array $args     Sidebar arguments.
	 * @param array $instance Widget settings.
	 */
	public function widget( $args, $instance ) {
		$links = isset( $instance['links'] ) ? trim( $instance['links'] ) : '';

		if ( '' === $links ) {
			return;
		}

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title'] );
		}

		$brands = self::brands();
		$colored = ! empty( $instance['colors'] );

		echo '<div class="cv-card__body"><div class="cv-social">';

		foreach ( preg_split( '/\r\n|\r|\n/', $links ) as $line ) {
			$parts = array_map( 'trim', explode( '|', $line, 2 ) );

			if ( count( $parts ) < 2 || '' === $parts[0] || '' === $parts[1] ) {
				continue;
			}

			$slug  = sanitize_title( $parts[0] );
			$style = ( $colored && isset( $brands[ $slug ] ) ) ? sprintf( ' style="background:%s;border-color:%s;color:#fff;"', esc_attr( $brands[ $slug ] ), esc_attr( $brands[ $slug ] ) ) : '';

			printf(
				'<a class="cv-social__link cv-social__link--%1$s" href="%2$s" target="_blank" rel="noopener me"%3$s>%4$s</a>',
				esc_attr( $slug ),
				esc_url( $parts[1] ),
				$style, // phpcs:ignore WordPress.Security.EscapeOutput
				esc_html( $parts[0] )
			);
		}

		echo '</div></div>';
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Settings form.
	 *
	 * @param array $instance Widget settings.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? (string) $instance['title'] : '';
		$links  = isset( $instance['links'] ) ? $instance['links'] : "Mastodon|https://\nGitHub|https://";
		$colors = isset( $instance['colors'] ) ? (bool) $instance['colors'] : true;
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'clevie-social' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'links' ) ); ?>"><?php esc_html_e( 'Links, one per line as Name|URL:', 'clevie-social' ); ?></label>
			<textarea class="widefat" rows="6" id="<?php echo esc_attr( $this->get_field_id( 'links' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'links' ) ); ?>"><?php echo esc_textarea( $links ); ?></textarea>
		</p>
		<p>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'colors' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'colors' ) ); ?>" <?php checked( $colors ); ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'colors' ) ); ?>"><?php esc_html_e( 'Use brand colors for known networks', 'clevie-social' ); ?></label>
		</p>
		<?php
	}

	/**
	 * Save the settings.
	 *
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return array(
			'title'  => sanitize_text_field( $new_instance['title'] ),
			'links'  => sanitize_textarea_field( $new_instance['links'] ),
			'colors' => ! empty( $new_instance['colors'] ),
		);
	}
}

/**
 * Register the widgets.
 */
function clevie_register_widgets() {
	register_widget( 'Clevie_Posts_Widget' );
	register_widget( 'Clevie_About_Widget' );
	register_widget( 'Clevie_Social_Widget' );
}
add_action( 'widgets_init', 'clevie_register_widgets' );
