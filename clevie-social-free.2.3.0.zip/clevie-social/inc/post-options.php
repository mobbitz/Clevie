<?php
/**
 * Post options: meta, sharing, author box, related posts, breadcrumbs.
 *
 * @package Clevie Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Estimated reading time in minutes.
 *
 * @param int|null $post_id Post ID.
 * @return int
 */
function clevie_reading_time( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$words   = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) );
	$minutes = (int) ceil( $words / max( 100, (int) get_theme_mod( 'clevie_reading_speed', 200 ) ) );

	return max( 1, $minutes );
}

/**
 * Breadcrumb trail.
 */
function clevie_breadcrumbs() {
	if ( ! get_theme_mod( 'clevie_breadcrumbs', true ) || is_front_page() ) {
		return;
	}

	$items = array( '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'clevie-social' ) . '</a>' );

	if ( is_singular( 'post' ) ) {
		$cats = get_the_category();
		if ( ! empty( $cats ) ) {
			$items[] = '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
		}
		$items[] = '<span aria-current="page">' . esc_html( get_the_title() ) . '</span>';
	} elseif ( is_page() ) {
		$parent = wp_get_post_parent_id( get_the_ID() );
		if ( $parent ) {
			$items[] = '<a href="' . esc_url( get_permalink( $parent ) ) . '">' . esc_html( get_the_title( $parent ) ) . '</a>';
		}
		$items[] = '<span aria-current="page">' . esc_html( get_the_title() ) . '</span>';
	} elseif ( is_search() ) {
		$items[] = '<span aria-current="page">' . esc_html__( 'Search', 'clevie-social' ) . '</span>';
	} elseif ( is_404() ) {
		$items[] = '<span aria-current="page">404</span>';
	} elseif ( is_archive() ) {
		$items[] = '<span aria-current="page">' . wp_kses_post( get_the_archive_title() ) . '</span>';
	} else {
		return;
	}

	printf(
		'<nav class="cv-breadcrumbs" aria-label="%1$s">%2$s</nav>',
		esc_attr__( 'Breadcrumb', 'clevie-social' ),
		wp_kses_post( implode( '<span class="cv-breadcrumbs__sep">/</span>', $items ) )
	);
}

/**
 * Share links without any third party script.
 */
function clevie_share_links() {
	if ( ! get_theme_mod( 'clevie_single_share', true ) ) {
		return;
	}

	$url   = rawurlencode( get_permalink() );
	$title = rawurlencode( get_the_title() );

	$networks = array(
		'x'        => array( 'X', 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title ),
		'facebook' => array( 'Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' . $url ),
		'linkedin' => array( 'LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url ),
		'whatsapp' => array( 'WhatsApp', 'https://api.whatsapp.com/send?text=' . $title . '%20' . $url ),
		'email'    => array( __( 'Email', 'clevie-social' ), 'mailto:?subject=' . $title . '&body=' . $url ),
	);

	echo '<div class="cv-share"><span class="cv-share__label">' . esc_html__( 'Share', 'clevie-social' ) . '</span>';

	foreach ( $networks as $key => $data ) {
		printf(
			'<a class="cv-share__link cv-share__link--%1$s" href="%2$s" target="_blank" rel="noopener nofollow">%3$s</a>',
			esc_attr( $key ),
			esc_url( $data[1] ),
			esc_html( $data[0] )
		);
	}

	printf(
		'<button type="button" class="cv-share__copy" data-url="%1$s">%2$s</button>',
		esc_url( get_permalink() ),
		esc_html__( 'Copy link', 'clevie-social' )
	);

	echo '</div>';
}

/**
 * Author box below a post.
 */
function clevie_author_box( $context = 'post' ) {
	if ( ! get_theme_mod( 'clevie_single_author_box', true ) ) {
		return;
	}

	if ( get_theme_mod( 'clevie_author_box_position', 'none' ) !== $context ) {
		return;
	}

	$description = get_the_author_meta( 'description' );
	?>
	<section class="cv-author cv-author--<?php echo esc_attr( $context ); ?>">
		<div class="cv-author__inner">
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 56 ); ?>
			<div class="cv-author__text">
				<?php if ( 'post' === $context ) : ?>
					<span class="cv-author__label"><?php esc_html_e( 'Written by', 'clevie-social' ); ?></span>
				<?php endif; ?>
				<h2 class="cv-author__name">
					<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( clevie_user_prefix() . get_the_author() ); ?></a>
				</h2>
				<?php if ( $description ) : ?>
					<p class="cv-author__bio"><?php echo esc_html( $description ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php
}

/**
 * Related posts below a post.
 */
function clevie_related_posts() {
	if ( ! get_theme_mod( 'clevie_single_related', true ) ) {
		return;
	}

	$count = (int) get_theme_mod( 'clevie_related_count', 3 );
	$by    = get_theme_mod( 'clevie_related_by', 'category' );
	$args  = array(
		'post__not_in'        => array( get_the_ID() ),
		'posts_per_page'      => $count,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	if ( 'tag' === $by ) {
		$tags = wp_get_post_tags( get_the_ID(), array( 'fields' => 'ids' ) );
		if ( empty( $tags ) ) {
			return;
		}
		$args['tag__in'] = $tags;
	} else {
		$cats = wp_get_post_categories( get_the_ID() );
		if ( empty( $cats ) ) {
			return;
		}
		$args['category__in'] = $cats;
	}

	$related = new WP_Query( $args );

	if ( ! $related->have_posts() ) {
		return;
	}
	?>
	<section class="cv-related cv-card">
		<h2 class="cv-card__head"><?php esc_html_e( 'More like this', 'clevie-social' ); ?></h2>
		<div class="cv-card__body">
			<div class="cv-related__grid" style="--cv-related-cols:<?php echo absint( min( 4, max( 1, $count ) ) ); ?>;">
				<?php
				while ( $related->have_posts() ) :
					$related->the_post();
					?>
					<a class="cv-related__item" href="<?php the_permalink(); ?>">
						<?php if ( has_post_thumbnail() ) : ?>
							<span class="cv-related__thumb"><?php the_post_thumbnail( 'clevie-card', array( 'loading' => 'lazy' ) ); ?></span>
						<?php endif; ?>
						<span class="cv-related__title"><?php the_title(); ?></span>
						<span class="cv-related__date"><?php echo esc_html( get_the_date() ); ?></span>
					</a>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		</div>
	</section>
	<?php
}

/**
 * One post in the stream, ready to print.
 */
function clevie_stream_item() {
	if ( post_password_required() ) {
		return;
	}

	$media = clevie_post_media( null, 'feed' );
	$short = clevie_is_short();
	?>
	<article <?php post_class( 'cv-post cv-single cv-stream__item' . ( $media ? ' cv-stream__item--media' : '' ) ); ?>>
		<div class="cv-post__inner">
			<?php clevie_post_meta(); ?>

			<h2 class="cv-post__title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h2>

			<?php if ( $media ) : ?>
				<!-- In a stream the video sits above the text: a column beside it
				     would leave both of them too narrow to be worth much. -->
				<?php $blur = ( $short && has_post_thumbnail() ) ? get_the_post_thumbnail_url( null, 'large' ) : ''; ?>
				<div class="cv-streammedia<?php echo $short ? ' cv-streammedia--upright' : ''; ?>"
					<?php echo $blur ? 'style="--cv-blur-src:url(' . esc_url( $blur ) . ');"' : ''; ?>>
					<?php echo $media; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
			<?php elseif ( has_post_thumbnail() ) : ?>
				<a class="cv-post__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
					<?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
				</a>
			<?php endif; ?>

			<?php
			$body = apply_filters( 'the_content', get_the_content() );

			// A long article inside a stream buries whatever comes after it, so
			// it is folded away behind a button. The measure is the text without
			// its markup: a post that is mostly a picture is not a long one.
			$long = ( mb_strlen( wp_strip_all_tags( $body ) ) > (int) apply_filters( 'clevie_stream_fold_at', 900 ) );
			?>

			<?php if ( $long ) : ?>
				<div class="cv-entry cv-fold" data-fold>
					<div class="cv-fold__body">
						<?php echo $body; // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</div>
					<button type="button" class="cv-fold__button">
						<span class="cv-fold__more"><?php esc_html_e( 'Read more', 'clevie-social' ); ?></span>
						<span class="cv-fold__less"><?php esc_html_e( 'Show less', 'clevie-social' ); ?></span>
					</button>
				</div>
			<?php else : ?>
				<div class="cv-entry">
					<?php echo $body; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
			<?php endif; ?>

			<div class="cv-postfoot">
				<div class="cv-postfoot__pill">
					<?php
					if ( 'bar' === clevie_vote_style() ) {
						clevie_vote_bar( true );
					}
					?>
				</div>

				<a class="cv-postfoot__author" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
					<?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
					<span><?php echo esc_html( clevie_user_prefix() . get_the_author() ); ?></span>
				</a>

				<?php
				$comments = (int) get_comments_number();

				if ( comments_open() || $comments ) :
					?>
					<a class="cv-stream__more" href="<?php echo esc_url( get_permalink() . '#comments' ); ?>">
						<?php
						if ( $comments ) {
							printf(
								/* translators: %s: number of comments. */
								esc_html( _n( '%s comment', '%s comments', $comments, 'clevie-social' ) ),
								esc_html( number_format_i18n( $comments ) )
							);
						} else {
							esc_html_e( 'Write the first comment', 'clevie-social' );
						}
						?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</article>
	<?php
}

/**
 * Query for one batch of the stream.
 *
 * @param int $post_id Post the reader started from.
 * @param int $offset  How many were shown already.
 * @param int $count   Size of the batch.
 * @return WP_Query
 */
function clevie_stream_query( $post_id, $offset = 0, $count = 3 ) {
	$cats = wp_get_post_categories( $post_id );

	$args = array(
		'post__not_in'        => array( $post_id ),
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $count,
		'offset'              => $offset,
		'ignore_sticky_posts' => true,
	);

	// Stay inside the topic, unless there is nothing else in it.
	if ( ! empty( $cats ) ) {
		$args['category__in'] = $cats;
	}

	return new WP_Query( $args );
}

/**
 * The stream under a post: the next ones in full, and the batch after that once
 * the reader gets there. Loading the whole topic at once would mean a page of
 * fifty articles with all their images.
 */
function clevie_next_post_card() {
	if ( ! clevie_can( 'stream' ) ) {
		clevie_related_posts();
		return;
	}

	$count   = max( 1, (int) get_theme_mod( 'clevie_stream_count', 3 ) );
	$post_id = get_the_ID();
	$stream  = clevie_stream_query( $post_id, 0, $count );

	if ( ! $stream->have_posts() ) {
		return;
	}

	echo '<div class="cv-stream">';
	echo '<span class="cv-stream__label">' . esc_html__( 'Read on', 'clevie-social' ) . '</span>';
	echo '<div class="cv-stream__items">';

	while ( $stream->have_posts() ) {
		$stream->the_post();
		clevie_stream_item();
	}

	echo '</div>';

	wp_reset_postdata();

	$more = ( $stream->found_posts > $count );

	printf(
		'<div class="cv-stream__end"%1$s data-post="%2$d" data-offset="%3$d" data-count="%4$d">
			<button type="button" class="cv-btn cv-btn--outline cv-stream__button">%5$s</button>
			<span class="cv-stream__spinner" hidden>%6$s</span>
		</div>',
		$more ? '' : ' hidden',
		absint( $post_id ),
		absint( $count ),
		absint( $count ),
		esc_html__( 'Load more', 'clevie-social' ),
		esc_html__( 'Loading …', 'clevie-social' )
	);

	echo '</div>';
}

/**
 * Endpoint the stream asks for its next batch.
 */
function clevie_stream_route() {
	register_rest_route(
		'clevie/v1',
		'/stream',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'permission_callback' => '__return_true',
			'callback'            => 'clevie_stream_rest',
			'args'                => array(
				'post'   => array( 'required' => true, 'sanitize_callback' => 'absint' ),
				'offset' => array( 'required' => false, 'sanitize_callback' => 'absint' ),
				'count'  => array( 'required' => false, 'sanitize_callback' => 'absint' ),
			),
		)
	);
}
add_action( 'rest_api_init', 'clevie_stream_route' );

/**
 * Render the next batch.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function clevie_stream_rest( $request ) {
	$post_id = absint( $request->get_param( 'post' ) );
	$offset  = min( 2000, absint( $request->get_param( 'offset' ) ) );
	$count   = max( 1, min( 10, absint( $request->get_param( 'count' ) ) ) );

	// Only ever built around a post that is actually public.
	$post = get_post( $post_id );

	if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status || post_password_required( $post ) ) {
		return rest_ensure_response( array( 'html' => '', 'offset' => $offset, 'has_more' => false ) );
	}

	$stream = clevie_stream_query( $post_id, $offset, $count );

	ob_start();

	while ( $stream->have_posts() ) {
		$stream->the_post();
		clevie_stream_item();
	}

	$html = ob_get_clean();

	wp_reset_postdata();

	return rest_ensure_response( array(
		'html'     => $html,
		'offset'   => $offset + $count,
		'has_more' => ( $stream->found_posts > ( $offset + $count ) ),
	) );
}

/**
 * Register the blog and single post controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function clevie_post_options_customize( $wp_customize ) {

	/* ---------- Blog and archives ---------- */
	$wp_customize->add_section( 'clevie_blog', array(
		'title'       => __( 'Blog and archives', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'These apply to the feed, to the magazine tiles and to archive pages.', 'clevie-social' ),
	) );

	$meta_fields = array(
		'clevie_meta_category' => __( 'Show the category', 'clevie-social' ),
		'clevie_meta_author'   => __( 'Show the author', 'clevie-social' ),
		'clevie_meta_date'     => __( 'Show the date', 'clevie-social' ),
		'clevie_meta_comments' => __( 'Show the comment count', 'clevie-social' ),
		'clevie_meta_reading'  => __( 'Show the reading time', 'clevie-social' ),
	);

	foreach ( $meta_fields as $id => $label ) {
		$wp_customize->add_setting( $id, array(
			'default'           => ( 'clevie_meta_reading' !== $id ),
			'sanitize_callback' => 'clevie_sanitize_checkbox',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $label,
			'section' => 'clevie_blog',
			'type'    => 'checkbox',
		) );
	}

	$wp_customize->add_setting( 'clevie_reading_speed', array(
		'default'           => 200,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_reading_speed', array(
		'label'       => __( 'Reading speed in words per minute', 'clevie-social' ),
		'description' => __( 'Words per minute used to work out the reading time. Two hundred is the usual estimate for German and English.', 'clevie-social' ),
		'section'     => 'clevie_blog',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 100, 'max' => 400, 'step' => 10 ),
	) );

	$wp_customize->add_setting( 'clevie_read_more_text', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'clevie_read_more_text', array(
		'label'       => __( 'Label of the read more link', 'clevie-social' ),
		'description' => __( 'Leave empty for "Read more".', 'clevie-social' ),
		'section'     => 'clevie_blog',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'clevie_breadcrumbs', array(
		'default'           => true,
		'sanitize_callback' => 'clevie_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'clevie_breadcrumbs', array(
		'label'   => __( 'Show breadcrumbs', 'clevie-social' ),
		'section' => 'clevie_blog',
		'type'    => 'checkbox',
	) );

	/* ---------- Single post ---------- */
	$wp_customize->add_section( 'clevie_single', array(
		'title'       => __( 'Single post', 'clevie-social' ),
		'panel'       => 'clevie_panel',
		'description' => __( 'What a post carries around its text: the picture, the sharing row, the author, and what follows the comments.', 'clevie-social' ),
	) );

	$wp_customize->add_setting( 'clevie_after_comments', array(
		'default'           => 'related',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_after_comments', array(
		'label'       => __( 'Below the comments', 'clevie-social' ),
		'description' => clevie_upgrade_notice( 'stream' ),
		'description' => __( 'What follows the discussion under a post.', 'clevie-social' ),
		'section'     => 'clevie_single',
		'type'        => 'select',
		'choices'     => array(
			'related' => __( 'Related posts', 'clevie-social' ),
			'next'    => __( 'The next posts in full', 'clevie-social' ),
			'none'    => __( 'Nothing', 'clevie-social' ),
		),
	) );

	$wp_customize->add_setting( 'clevie_stream_count', array(
		'default'           => 3,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_stream_count', array(
		'label'       => __( 'Posts per batch', 'clevie-social' ),
		'description' => __( 'The stream runs through the whole topic, but in batches. This is the size of one batch; the next arrives once the reader gets to the end.', 'clevie-social' ),
		'section'     => 'clevie_single',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 1, 'max' => 6 ),
	) );

	$wp_customize->add_setting( 'clevie_author_box_position', array(
		'default'           => 'none',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_author_box_position', array(
		'label'       => __( 'Where the author box goes', 'clevie-social' ),
		'description' => __( 'Avatar, name and the About text of the author. In the sidebar the box stays in view while reading.', 'clevie-social' ),
		'section'     => 'clevie_single',
		'type'        => 'select',
		'choices'     => array(
			'none'    => __( 'Not at all, the name is under the post anyway', 'clevie-social' ),
			'post'    => __( 'Inside the post', 'clevie-social' ),
			'sidebar' => __( 'In the right sidebar', 'clevie-social' ),
		),
	) );

	$toggles = array(
		'clevie_single_featured'   => array( __( 'Show the featured image', 'clevie-social' ), true ),
		'clevie_single_share'      => array( __( 'Show share links', 'clevie-social' ), true ),
		'clevie_single_author_box' => array( __( 'Show the author box', 'clevie-social' ), true ),
		'clevie_single_related'    => array( __( 'Show related posts', 'clevie-social' ), true ),
		'clevie_single_nav'        => array( __( 'Show links to the previous and next post', 'clevie-social' ), false ),
		'clevie_reading_progress'  => array( __( 'Show a reading progress bar', 'clevie-social' ), false ),
	);

	foreach ( $toggles as $id => $data ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $data[1],
			'sanitize_callback' => 'clevie_sanitize_checkbox',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $data[0],
			'section' => 'clevie_single',
			'type'    => 'checkbox',
		) );
	}

	$wp_customize->add_setting( 'clevie_related_by', array(
		'default'           => 'category',
		'sanitize_callback' => 'clevie_sanitize_select',
	) );
	$wp_customize->add_control( 'clevie_related_by', array(
		'label'   => __( 'Pick related posts by', 'clevie-social' ),
		'description' => __( 'How the related posts under an article are picked.', 'clevie-social' ),
		'section' => 'clevie_single',
		'type'    => 'select',
		'choices' => array(
			'category' => __( 'Same category', 'clevie-social' ),
			'tag'      => __( 'Same tag', 'clevie-social' ),
		),
	) );

	$wp_customize->add_setting( 'clevie_related_count', array(
		'default'           => 3,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'clevie_related_count', array(
		'label'       => __( 'Number of related posts', 'clevie-social' ),
		'description' => __( 'How many related posts are shown.', 'clevie-social' ),
		'section'     => 'clevie_single',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 1, 'max' => 8 ),
	) );
}
add_action( 'customize_register', 'clevie_post_options_customize', 14 );
