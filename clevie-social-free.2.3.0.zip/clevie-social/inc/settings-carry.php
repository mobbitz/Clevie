<?php
/**
 * Carry the Customizer settings across when the free and paid themes swap.
 *
 * WordPress files these per stylesheet directory. The paid build lives in
 * clevie-social-premium and the free one in clevie-social, so as far as
 * WordPress is concerned an upgrade is a move to an entirely different theme:
 * colours, logo, header, layout and menu positions all go back to their
 * defaults. Nothing is deleted, it is simply looked for under a name that has
 * nothing in it yet.
 *
 * Two things have to be brought over, and it is easy to remember only the
 * first. theme_mods_{slug} holds the Customizer settings, and Additional CSS
 * lives somewhere else entirely: a post of type custom_css whose post_name is
 * the stylesheet directory.
 *
 * Anything already set on the side being switched to is left alone. Somebody
 * who has been configuring the paid theme should not have it quietly replaced
 * by older settings because they briefly went back to the free one.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The two directories this theme ships under.
 *
 * @return string[]
 */
function clevie_sibling_directories() {
	return array( 'clevie-social', 'clevie-social-premium' );
}

/**
 * The other one.
 *
 * @param string $directory Current directory.
 * @return string Empty when this is not one of ours.
 */
function clevie_sibling_of( $directory ) {
	$siblings = clevie_sibling_directories();

	if ( ! in_array( $directory, $siblings, true ) ) {
		return '';
	}

	return ( $siblings[0] === $directory ) ? $siblings[1] : $siblings[0];
}

/**
 * Has this side been set up already?
 *
 * A freshly switched theme often has a theme_mods entry containing nothing but
 * bookkeeping: a numeric placeholder and the widget map WordPress works out on
 * its own. That is not somebody's configuration, so it does not count.
 *
 * @param string $directory Directory to look at.
 * @return bool
 */
function clevie_mods_configured( $directory ) {
	$mods = get_option( 'theme_mods_' . $directory );

	if ( ! is_array( $mods ) ) {
		return false;
	}

	foreach ( $mods as $key => $value ) {
		if ( 0 === $key || '0' === $key || 'sidebars_widgets' === $key ) {
			continue;
		}

		return true;
	}

	return false;
}

/**
 * Bring the settings over after a switch.
 */
function clevie_carry_settings_over() {
	$current = get_stylesheet();
	$other   = clevie_sibling_of( $current );

	if ( ! $other ) {
		return;
	}

	if ( clevie_mods_configured( $current ) ) {
		return;
	}

	if ( ! clevie_mods_configured( $other ) ) {
		return;
	}

	$mods = get_option( 'theme_mods_' . $other );

	if ( ! is_array( $mods ) ) {
		return;
	}

	// The widget map belongs to whichever theme is running and was just worked
	// out for this one. Carrying the old one over would undo that.
	unset( $mods['sidebars_widgets'] );

	update_option( 'theme_mods_' . $current, $mods );

	clevie_carry_custom_css_over( $current, $other );

	/**
	 * Fires after the settings were carried across.
	 *
	 * @param string $current Directory switched to.
	 * @param string $other   Directory they came from.
	 */
	do_action( 'clevie_settings_carried_over', $current, $other );
}
add_action( 'after_switch_theme', 'clevie_carry_settings_over' );

/**
 * Bring Additional CSS over.
 *
 * @param string $current Directory switched to.
 * @param string $other   Directory to take it from.
 */
function clevie_carry_custom_css_over( $current, $other ) {
	if ( ! function_exists( 'wp_get_custom_css_post' ) ) {
		return;
	}

	$mine = wp_get_custom_css_post( $current );

	if ( $mine && '' !== trim( (string) $mine->post_content ) ) {
		return;
	}

	$theirs = wp_get_custom_css_post( $other );

	if ( ! $theirs || '' === trim( (string) $theirs->post_content ) ) {
		return;
	}

	wp_update_custom_css_post( $theirs->post_content, array( 'stylesheet' => $current ) );
}

/**
 * Say what happened.
 *
 * Quietly moving somebody's settings is the kind of helpfulness that reads as a
 * bug when it is not mentioned, so it is mentioned.
 */
function clevie_carry_settings_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

	if ( ! $screen || 'themes' !== $screen->id ) {
		return;
	}

	if ( ! get_transient( 'clevie_settings_carried' ) ) {
		return;
	}

	delete_transient( 'clevie_settings_carried' );

	printf(
		'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
		esc_html__( 'Your Customizer settings were brought across from the other edition of Clevie Social.', 'clevie-social' )
	);
}
add_action( 'admin_notices', 'clevie_carry_settings_notice' );

/**
 * Remember that it happened, for the notice above.
 */
function clevie_carry_settings_remember() {
	set_transient( 'clevie_settings_carried', 1, 5 * MINUTE_IN_SECONDS );
}
add_action( 'clevie_settings_carried_over', 'clevie_carry_settings_remember' );
