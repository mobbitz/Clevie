<?php
/**
 * A second logo for the dark mode.
 *
 * WordPress has one custom logo and no idea that a site might have two modes. A
 * logo drawn in dark ink disappears on a dark background, and one drawn in white
 * disappears on a light one; a site with a mode switch needs both, and asking
 * people to make a single logo that works on either is asking them to make a
 * worse logo.
 *
 * The second one is optional. Left empty, the ordinary logo is used in both
 * modes, exactly as before.
 *
 * Both are printed, and CSS shows whichever belongs to the mode in force. That
 * matters: the mode can be switched without reloading, so choosing in PHP would
 * leave the wrong logo on screen until the next page.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The picker in the Customizer, next to the ordinary logo.
 *
 * @param WP_Customize_Manager $wp_customize The manager.
 */
function clevie_dark_logo_customize( $wp_customize ) {
	$wp_customize->add_setting( 'clevie_logo_dark', array(
		'default'           => 0,
		'sanitize_callback' => 'absint',
	) );

	$wp_customize->add_control(
		new WP_Customize_Media_Control( $wp_customize, 'clevie_logo_dark', array(
			'label'       => __( 'Logo for the dark mode', 'clevie-social' ),
			'description' => __( 'Optional. A logo in dark ink vanishes on a dark background. Leave this empty and the ordinary logo is used in both modes.', 'clevie-social' ),
			'section'     => 'title_tagline',
			'mime_type'   => 'image',
			'priority'    => 9,
		) )
	);
}
add_action( 'customize_register', 'clevie_dark_logo_customize', 20 );

/**
 * Is there one?
 *
 * @return int Attachment ID, or zero.
 */
function clevie_dark_logo_id() {
	return (int) get_theme_mod( 'clevie_logo_dark', 0 );
}

/**
 * Print the dark logo alongside the ordinary one.
 *
 * @param string $html The markup WordPress built.
 * @return string
 */
function clevie_dark_logo_markup( $html ) {
	$id = clevie_dark_logo_id();

	if ( ! $id || ! $html ) {
		return $html;
	}

	$image = wp_get_attachment_image( $id, 'full', false, array(
		'class' => 'custom-logo cv-logo--dark',
		'alt'   => get_bloginfo( 'name', 'display' ),
	) );

	if ( ! $image ) {
		return $html;
	}

	// The one WordPress made is marked as the light one, and the second goes in
	// beside it inside the same link.
	$html = str_replace( 'class="custom-logo"', 'class="custom-logo cv-logo--light"', $html );

	return str_replace( '</a>', $image . '</a>', $html );
}
add_filter( 'get_custom_logo', 'clevie_dark_logo_markup' );

/**
 * Show the right one for the mode.
 *
 * Only printed when a second logo exists, so a site with one logo carries no
 * rules it does not need.
 */
function clevie_dark_logo_css() {
	if ( ! clevie_dark_logo_id() ) {
		return;
	}

	wp_add_inline_style(
		'clevie-style',
		'.cv-logo--dark{display:none}' .
		'[data-theme="dark"] .cv-logo--light{display:none}' .
		'[data-theme="dark"] .cv-logo--dark{display:inline-block}'
	);
}
add_action( 'wp_enqueue_scripts', 'clevie_dark_logo_css', 21 );
