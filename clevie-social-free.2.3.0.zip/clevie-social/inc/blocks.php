<?php
/**
 * Block styles and patterns.
 *
 * Small additions that make the block editor feel like part of the theme rather
 * than something bolted on.
 *
 * @package Clevie_Social
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Styles a writer can pick from the block sidebar.
 */
function clevie_register_block_styles() {
	if ( ! function_exists( 'register_block_style' ) ) {
		return;
	}

	register_block_style( 'core/quote', array(
		'name'  => 'clevie-plain',
		'label' => __( 'Without a line', 'clevie-social' ),
	) );

	register_block_style( 'core/image', array(
		'name'  => 'clevie-rounded',
		'label' => __( 'Rounded corners', 'clevie-social' ),
	) );

	register_block_style( 'core/list', array(
		'name'  => 'clevie-checks',
		'label' => __( 'With ticks', 'clevie-social' ),
	) );

	register_block_style( 'core/group', array(
		'name'  => 'clevie-card',
		'label' => __( 'As a card', 'clevie-social' ),
	) );
}
add_action( 'init', 'clevie_register_block_styles' );

/**
 * Ready-made pieces for the pages a community needs anyway.
 */
function clevie_register_block_patterns() {
	if ( ! function_exists( 'register_block_pattern_category' ) ) {
		return;
	}

	register_block_pattern_category( 'clevie', array(
		'label' => __( 'Clevie', 'clevie-social' ),
	) );

	register_block_pattern( 'clevie/rules', array(
		'title'      => __( 'Community rules', 'clevie-social' ),
		'categories' => array( 'clevie' ),
		'content'    => '<!-- wp:heading --><h2>' . esc_html__( 'How we treat each other here', 'clevie-social' ) . '</h2><!-- /wp:heading -->'
			. '<!-- wp:list --><ul>'
			. '<li>' . esc_html__( 'Say what you mean, and say it to the point being made rather than to the person making it.', 'clevie-social' ) . '</li>'
			. '<li>' . esc_html__( 'Search before you ask. The answer is often already here.', 'clevie-social' ) . '</li>'
			. '<li>' . esc_html__( 'No advertising, no chain posts, nothing you were paid to write.', 'clevie-social' ) . '</li>'
			. '<li>' . esc_html__( 'Report what breaks these rules instead of arguing with it.', 'clevie-social' ) . '</li>'
			. '</ul><!-- /wp:list -->',
	) );

	register_block_pattern( 'clevie/welcome', array(
		'title'      => __( 'Welcome box', 'clevie-social' ),
		'categories' => array( 'clevie' ),
		'content'    => '<!-- wp:group {"className":"is-style-clevie-card"} --><div class="wp-block-group is-style-clevie-card">'
			. '<!-- wp:heading {"level":3} --><h3>' . esc_html__( 'New here?', 'clevie-social' ) . '</h3><!-- /wp:heading -->'
			. '<!-- wp:paragraph --><p>' . esc_html__( 'Pick a community that interests you, follow it, and write something. That is the whole thing.', 'clevie-social' ) . '</p><!-- /wp:paragraph -->'
			. '</div><!-- /wp:group -->',
	) );
}
add_action( 'init', 'clevie_register_block_patterns' );
