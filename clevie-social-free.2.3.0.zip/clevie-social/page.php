<?php
/**
 * Static page.
 *
 * @package Clevie Social
 */

get_header();

while ( have_posts() ) :
	the_post();

	get_template_part( 'template-parts/content', 'single' );

	if ( comments_open() || get_comments_number() ) {
		echo '<div class="cv-card cv-comments-wrap">';
		comments_template();
		echo '</div>';
	}

endwhile;

get_footer();
