<?php
/**
 * Footer.
 *
 * @package Clevie Social
 */

?>
	</main><!-- .cv-col--main -->

	<?php get_sidebar(); ?>

</div><!-- .cv-shell -->

<?php if ( is_active_sidebar( 'footer-widgets' ) ) : ?>
	<div class="cv-footer-widgets cv-widgets">
		<div class="cv-footer__inner" style="--cv-footer-cols:<?php echo absint( get_theme_mod( 'clevie_footer_columns', 3 ) ); ?>;">
			<?php dynamic_sidebar( 'footer-widgets' ); ?>
		</div>
	</div>
<?php endif; ?>

<footer class="cv-footer">
	<div class="cv-footer__inner">
		<div class="cv-footer__text">
			<?php
			$footer_text = get_theme_mod( 'clevie_footer_text', '' );
			if ( $footer_text ) {
				echo wp_kses_post( $footer_text );
			} else {
				printf(
					/* translators: 1: year, 2: site title. */
					esc_html__( '© %1$s %2$s', 'clevie-social' ),
					esc_html( gmdate( 'Y' ) ),
					esc_html( get_bloginfo( 'name' ) )
				);
			}
			?>
		</div>

		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav class="cv-footer__menu" aria-label="<?php esc_attr_e( 'Footer menu', 'clevie-social' ); ?>">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => false,
				) );
				?>
			</nav>
		<?php endif; ?>
	</div>
</footer>

<?php if ( get_theme_mod( 'clevie_backtotop', true ) ) : ?>
	<button class="cv-backtotop" aria-label="<?php esc_attr_e( 'Back to top', 'clevie-social' ); ?>">
		<?php echo clevie_icon( 'top', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</button>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
