<?php
/**
 * Left column: primary menu with the “Left sidebar” widget area below it.
 *
 * @package Clevie Social
 */

if ( ! clevie_left_column_active() ) {
	return;
}
?>
<aside id="cv-left" class="cv-col cv-col--left">

	<?php if ( has_nav_menu( 'primary' ) ) : ?>
		<nav class="cv-card cv-nav" aria-label="<?php esc_attr_e( 'Primary menu', 'clevie-social' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'cv-nav__list',
				'depth'          => 3,
				'fallback_cb'    => false,
			) );
			?>
		</nav>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'sidebar-left' ) ) : ?>
		<div class="cv-widgets cv-widgets--left">
			<?php dynamic_sidebar( 'sidebar-left' ); ?>
		</div>
	<?php endif; ?>

</aside>
