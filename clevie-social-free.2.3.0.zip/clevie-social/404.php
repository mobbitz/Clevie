<?php
/**
 * 404 page.
 *
 * @package Clevie Social
 */

get_header();
?>

<section class="cv-card">
	<div class="cv-card__body">
		<h1><?php esc_html_e( 'This page does not exist', 'clevie-social' ); ?></h1>
		<p><?php esc_html_e( 'The link is wrong or the content was removed. Search for something else or head back to the homepage.', 'clevie-social' ); ?></p>
		<?php get_search_form(); ?>
		<p style="margin-top:16px;">
			<a class="cv-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the homepage', 'clevie-social' ); ?></a>
		</p>
	</div>
</section>

<?php
get_footer();
