<?php
/**
 * Single post.
 *
 * @package Clevie Social
 */

get_header();

while ( have_posts() ) :
	the_post();

	get_template_part( 'template-parts/content', 'single' );

	// What follows the discussion is a matter of taste, so it is a setting.
	$cv_after = get_theme_mod( 'clevie_after_comments', 'related' );

	if ( 'next' === $cv_after ) {
		clevie_next_post_card();
	} elseif ( 'related' === $cv_after ) {
		clevie_related_posts();
	}

	if ( get_theme_mod( 'clevie_single_nav', true ) ) {
		the_post_navigation( array(
			'class'     => 'cv-pagination cv-post-nav',
			'prev_text' => '&larr; %title',
			'next_text' => '%title &rarr;',
		) );
	}

endwhile;

get_footer();
