<?php

/**
 * Clevie Social theme functions.
 *
 * @package Clevie Social
 */
if ( !defined( 'ABSPATH' ) ) {
    exit;
}
define( 'CLEVIE_VERSION', '2.3.0' );
/**
 * Freemius licensing and updates.
 *
 * This integration follows the official Freemius theme integration pattern:
 * for themes, the SDK initialization lives in the root functions.php file.
 */
/**
 * Put the local Freemius product map right.
 *
 * Installations that once ran under a wrong module type carry a stale entry in
 * the Freemius accounts option, and the checkout fails because of it. This
 * writes the correct entry once and records that it has done so.
 *
 * Three things matter here. It only runs in the admin, because a visitor
 * reading an article has no business triggering a write to an option. It only
 * runs once, because the original version compared and wrote on every single
 * request. And it takes the directory name from get_template() rather than
 * hard-coding it: the paid edition lives in clevie-social-premium, and forcing
 * that installation back onto the free path is how you break the very licence
 * this was meant to fix.
 *
 * No account or licence data is touched, only the slug-to-path map.
 */
if ( !function_exists( 'clevie_fs_repair_module_map' ) ) {
    function clevie_fs_repair_module_map() {
        if ( !is_admin() ) {
            return;
        }
        $directory = get_template();
        if ( !$directory ) {
            return;
        }
        // The stored value is the directory the map was last written for, not a
        // plain yes. Switching between clevie-social and clevie-social-premium
        // changes the path Freemius has to know about, and a one-off flag would
        // leave the premium install pointing at the free folder: the very stale
        // entry this function exists to repair.
        if ( get_option( 'clevie_fs_map_repaired' ) === $directory ) {
            return;
        }
        if ( !class_exists( 'FS_Options' ) || !defined( 'WP_FS__ACCOUNTS_OPTION_NAME' ) || !defined( 'WP_FS__MODULE_TYPE_THEME' ) ) {
            return;
        }
        $accounts = FS_Options::instance( WP_FS__ACCOUNTS_OPTION_NAME, true );
        $map = $accounts->get_option( 'id_slug_type_path_map', array() );
        $expected = array(
            'slug' => $directory,
            'type' => WP_FS__MODULE_TYPE_THEME,
            'path' => $directory . '/functions.php',
        );
        if ( !isset( $map[36987] ) || $map[36987] !== $expected ) {
            $map[36987] = $expected;
            $accounts->set_option( 'id_slug_type_path_map', $map, true );
        }
        update_option( 'clevie_fs_map_repaired', $directory, false );
    }

}
if ( !function_exists( 'clevie_fs' ) ) {
    function clevie_fs() {
        global $clevie_fs;
        if ( !isset( $clevie_fs ) ) {
            require_once get_template_directory() . '/vendor/freemius/start.php';
            clevie_fs_repair_module_map();
            $clevie_fs = fs_dynamic_init( array(
                'id'                             => '36987',
                'slug'                           => 'clevie-social',
                'premium_slug'                   => 'clevie-social-premium',
                'type'                           => 'theme',
                'public_key'                     => 'pk_953202ca559c7ea834f448aabaa06',
                'is_premium'                     => false,
                'premium_suffix'                 => 'Pro',
                'has_addons'                     => true,
                'has_paid_plans'                 => true,
                'bundle_id'                      => '37143',
                'bundle_public_key'              => 'pk_b2757efddd92a643f56c7264ab093',
                'bundle_license_auto_activation' => true,
                'is_org_compliant'               => false,
                'menu'                           => array(
                    'first-path' => 'themes.php',
                    'pricing'    => true,
                    'support'    => false,
                ),
                'is_live'                        => true,
            ) );
        }
        return $clevie_fs;
    }

    clevie_fs();
    do_action( 'clevie_fs_loaded' );
}
/**
 * Basic theme setup.
 */
function clevie_setup() {
    load_theme_textdomain( 'clevie-social', get_template_directory() . '/languages' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', array(
        'height'      => 68,
        'width'       => 260,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ) );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'customize-selective-refresh-widgets' );
    // The styles the block editor brings for its own blocks.
    add_theme_support( 'wp-block-styles' );
    // A background of your own, on top of the colours the Customizer sets.
    add_theme_support( 'custom-background', array(
        'default-color' => '',
        'default-image' => '',
    ) );
    // A picture across the top of the page, above the header bar.
    add_theme_support( 'custom-header', array(
        'default-image' => '',
        'width'         => 1800,
        'height'        => 360,
        'flex-width'    => true,
        'flex-height'   => true,
        'header-text'   => false,
        'uploads'       => true,
    ) );
    // Cropped to 16:9 for grids and lists of thumbnails, where every tile has to
    // look the same.
    add_image_size(
        'clevie-card',
        640,
        360,
        true
    );
    // The same picture untouched, for the feed: an upright photo has to stay
    // upright, and no crop can be undone in the browser.
    add_image_size(
        'clevie-full',
        900,
        1400,
        false
    );
    register_nav_menus( array(
        'primary' => __( 'Primary menu (left column, below the logo)', 'clevie-social' ),
        'footer'  => __( 'Footer menu', 'clevie-social' ),
    ) );
}

add_action( 'after_setup_theme', 'clevie_setup' );
/**
 * Content width for embedded media.
 */
function clevie_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'clevie_content_width', 640 );
}

add_action( 'after_setup_theme', 'clevie_content_width', 0 );
/**
 * Register the widget areas.
 */
function clevie_widgets_init() {
    $defaults = array(
        'before_widget' => '<section id="%1$s" class="cv-widget cv-card %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="cv-card__head">',
        'after_title'   => '</h2>',
    );
    register_sidebar( array_merge( $defaults, array(
        'name'        => __( 'Right sidebar', 'clevie-social' ),
        'id'          => 'sidebar-right',
        'description' => __( 'Appears to the right of the feed, for the community box and widgets.', 'clevie-social' ),
    ) ) );
    register_sidebar( array_merge( $defaults, array(
        'name'        => __( 'Left sidebar (below the menu)', 'clevie-social' ),
        'id'          => 'sidebar-left',
        'description' => __( 'Appears in the left column, directly below the primary menu.', 'clevie-social' ),
    ) ) );
    register_sidebar( array_merge( $defaults, array(
        'name'        => __( 'Footer', 'clevie-social' ),
        'id'          => 'footer-widgets',
        'description' => __( 'Widgets above the footer, full width.', 'clevie-social' ),
    ) ) );
}

add_action( 'widgets_init', 'clevie_widgets_init' );
/**
 * Enqueue styles and scripts.
 */
function clevie_scripts() {
    wp_enqueue_style(
        'clevie-style',
        get_stylesheet_uri(),
        array(),
        CLEVIE_VERSION
    );
    wp_add_inline_style( 'clevie-style', clevie_customizer_css() );
    wp_enqueue_script(
        'clevie-script',
        get_template_directory_uri() . '/js/theme.js',
        array(),
        CLEVIE_VERSION,
        true
    );
    wp_localize_script( 'clevie-script', 'clevieSettings', array(
        'defaultScheme' => get_theme_mod( 'clevie_color_scheme', 'light' ),
        'streamRoot'    => esc_url_raw( rest_url( 'clevie/v1/stream' ) ),
    ) );
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}

add_action( 'wp_enqueue_scripts', 'clevie_scripts' );
/**
 * Set the color scheme as early as possible so the page does not flash on load.
 */
function clevie_no_flash_script() {
    $default = get_theme_mod( 'clevie_color_scheme', 'light' );
    ?>
	<script>
	(function () {
		var d = <?php 
    echo wp_json_encode( $default );
    ?>;
		var s = null;
		try { s = localStorage.getItem('clevie-scheme'); } catch (e) {}
		if (!s) {
			s = (d === 'auto')
				? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
				: d;
		}
		document.documentElement.setAttribute('data-theme', s);
	})();
	</script>
	<?php 
}

add_action( 'wp_head', 'clevie_no_flash_script', 1 );
/**
 * Classes on the body element.
 *
 * @param array $classes Existing classes.
 * @return array
 */
function clevie_body_classes(  $classes  ) {
    if ( !clevie_right_sidebar_active() ) {
        $classes[] = 'cv-no-right-sidebar';
    }
    $classes[] = 'cv-feed-' . get_theme_mod( 'clevie_feed_style', 'card' );
    $classes[] = 'cv-layout-' . clevie_current_layout();
    if ( is_page_template( 'template-magazin.php' ) || clevie_archives_use_magazine() ) {
        $classes[] = 'cv-magazine';
    }
    if ( get_theme_mod( 'clevie_leftbar_fixed', true ) && clevie_left_column_active() ) {
        $classes[] = 'cv-leftbar-fixed';
    }
    return $classes;
}

add_filter( 'body_class', 'clevie_body_classes' );
/**
 * Work out the layout class for the grid.
 *
 * @return string
 */
function clevie_shell_class() {
    $has_left = clevie_left_column_active();
    $has_right = clevie_right_sidebar_active();
    if ( $has_left && $has_right ) {
        return 'cv-shell';
    }
    if ( $has_left ) {
        return 'cv-shell cv-shell--no-right';
    }
    if ( $has_right ) {
        return 'cv-shell cv-shell--no-left';
    }
    return 'cv-shell cv-shell--full';
}

/**
 * Excerpt length.
 *
 * @param int $length Default length.
 * @return int
 */
function clevie_excerpt_length(  $length  ) {
    return (int) get_theme_mod( 'clevie_excerpt_length', 30 );
}

add_filter( 'excerpt_length', 'clevie_excerpt_length', 999 );
/**
 * Excerpt ending.
 *
 * @return string
 */
function clevie_excerpt_more() {
    return '&nbsp;&hellip;';
}

add_filter( 'excerpt_more', 'clevie_excerpt_more' );
/**
 * Score of a post, based on comments and filterable.
 *
 * @param int $post_id Post ID.
 * @return int
 */
function clevie_get_score(  $post_id = null  ) {
    $post_id = ( $post_id ? $post_id : get_the_ID() );
    $score = (int) get_post_meta( $post_id, 'clevie_score', true );
    if ( !$score ) {
        $score = (int) get_comments_number( $post_id );
    }
    return (int) apply_filters( 'clevie_post_score', $score, $post_id );
}

/**
 * Prefix in front of a topic name.
 *
 * @return string
 */
function clevie_topic_prefix() {
    return (string) apply_filters( 'clevie_topic_prefix', get_theme_mod( 'clevie_topic_prefix', 'to/' ) );
}

/**
 * Prefix in front of a member name.
 *
 * @return string
 */
function clevie_user_prefix() {
    return (string) apply_filters( 'clevie_user_prefix', get_theme_mod( 'clevie_user_prefix', 'm/' ) );
}

/**
 * WordPress writes "Category: name" above an archive. Here they are topics.
 *
 * @param string $title Title.
 * @return string
 */
function clevie_archive_title(  $title  ) {
    if ( is_category() ) {
        /* translators: %s: name of the topic. */
        return sprintf( __( 'Topic: %s', 'clevie-social' ), single_cat_title( '', false ) );
    }
    if ( is_tag() ) {
        /* translators: %s: name of the tag. */
        return sprintf( __( 'Tag: %s', 'clevie-social' ), single_tag_title( '', false ) );
    }
    if ( is_author() ) {
        return get_the_author();
    }
    return $title;
}

add_filter( 'get_the_archive_title', 'clevie_archive_title' );
/**
 * Is this post a short, upright video? A plugin decides, the theme only asks.
 *
 * @param int|null $post_id Post ID.
 * @return bool
 */
function clevie_is_short(  $post_id = null  ) {
    $post_id = ( $post_id ? $post_id : get_the_ID() );
    return (bool) apply_filters( 'clevie_is_short', false, $post_id );
}

/**
 * Does this post carry a video, upright or not? A plugin answers.
 *
 * @param int|null $post_id Post ID.
 * @return bool
 */
function clevie_post_has_video(  $post_id = null  ) {
    $post_id = ( $post_id ? $post_id : get_the_ID() );
    return (bool) apply_filters( 'clevie_post_has_video', false, $post_id );
}

/**
 * Player for a post, upright clip or ordinary video. A plugin fills this in.
 *
 * @param int|null $post_id Post ID.
 * @param string   $context 'feed' or 'single'.
 * @return string
 */
function clevie_post_media(  $post_id = null, $context = 'feed'  ) {
    $post_id = ( $post_id ? $post_id : get_the_ID() );
    return (string) apply_filters(
        'clevie_post_media',
        '',
        $post_id,
        $context
    );
}

/**
 * Markup of the upright video.
 *
 * @param int|null $post_id Post ID.
 * @param string   $context 'feed' or 'single'.
 * @return string
 */
function clevie_short_media(  $post_id = null, $context = 'feed'  ) {
    $post_id = ( $post_id ? $post_id : get_the_ID() );
    return (string) apply_filters(
        'clevie_short_media',
        '',
        $post_id,
        $context
    );
}

/**
 * How the vote element is displayed: 'bar', 'column' or 'none'.
 *
 * @return string
 */
function clevie_vote_style() {
    if ( !get_theme_mod( 'clevie_show_votes', true ) ) {
        return 'none';
    }
    $style = get_theme_mod( 'clevie_vote_style', 'bar' );
    return ( in_array( $style, array('bar', 'column'), true ) ? $style : 'bar' );
}

/**
 * Horizontal vote element. Classes and data attributes are stable so a voting
 * plugin can attach to them.
 *
 * @param bool $with_comments Append the comment count.
 */
function clevie_vote_bar(  $with_comments = false  ) {
    $score = clevie_get_score();
    ?>
	<div class="cv-votes cv-votes--bar" data-post-id="<?php 
    echo absint( get_the_ID() );
    ?>" data-score="<?php 
    echo esc_attr( $score );
    ?>">
		<span class="cv-votes__arrow cv-vote-up" aria-hidden="true"><?php 
    echo clevie_icon( 'up', 18 );
    // phpcs:ignore WordPress.Security.EscapeOutput
    ?></span>
		<span class="cv-votes__score">
			<?php 
    echo esc_html( number_format_i18n( $score ) );
    ?>
			<span class="screen-reader-text"><?php 
    esc_html_e( 'points', 'clevie-social' );
    ?></span>
		</span>
		<span class="cv-votes__arrow cv-vote-down" aria-hidden="true"><?php 
    echo clevie_icon( 'down', 18 );
    // phpcs:ignore WordPress.Security.EscapeOutput
    ?></span>

		<?php 
    if ( $with_comments ) {
        ?>
			<a class="cv-votes__comments" href="<?php 
        echo esc_url( get_comments_link() );
        ?>">
				<?php 
        echo clevie_icon( 'comment', 16 );
        // phpcs:ignore WordPress.Security.EscapeOutput
        ?>
				<?php 
        echo esc_html( number_format_i18n( get_comments_number() ) );
        ?>
			</a>
		<?php 
    }
    ?>
	</div>
	<?php 
}

/**
 * Output the meta line of a post.
 */
function clevie_post_meta() {
    $cats = get_the_category();
    $show_cat = get_theme_mod( 'clevie_meta_category', true ) && !empty( $cats );
    ?>
	<div class="cv-post__meta">
		<?php 
    if ( $show_cat ) {
        ?>
			<a class="cv-post__cat" href="<?php 
        echo esc_url( get_category_link( $cats[0]->term_id ) );
        ?>"><?php 
        echo esc_html( clevie_topic_prefix() . $cats[0]->name );
        ?></a>
		<?php 
    }
    ?>

		<?php 
    if ( get_theme_mod( 'clevie_meta_author', true ) ) {
        ?>
			<?php 
        if ( $show_cat ) {
            ?><span>&middot;</span><?php 
        }
        ?>
			<span><?php 
        esc_html_e( 'by', 'clevie-social' );
        ?> <a href="<?php 
        echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );
        ?>"><?php 
        echo esc_html( clevie_user_prefix() . get_the_author() );
        ?></a></span>
		<?php 
    }
    ?>

		<?php 
    if ( get_theme_mod( 'clevie_meta_date', true ) ) {
        ?>
			<span>&middot;</span>
			<time datetime="<?php 
        echo esc_attr( get_the_date( 'c' ) );
        ?>">
				<?php 
        /* translators: %s: time since publication. */
        printf( esc_html__( '%s ago', 'clevie-social' ), esc_html( human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) ) );
        ?>
			</time>
		<?php 
    }
    ?>

		<?php 
    if ( get_theme_mod( 'clevie_meta_reading', false ) ) {
        ?>
			<span>&middot;</span>
			<span>
				<?php 
        /* translators: %d: reading time in minutes. */
        printf( esc_html__( '%d min read', 'clevie-social' ), absint( clevie_reading_time() ) );
        ?>
			</span>
		<?php 
    }
    ?>

		<?php 
    /**
     * Room for actions that belong beside the author's name, such as blocking
     * the member who wrote the post.
     *
     * @param int $author_id The author.
     */
    do_action( 'clevie_post_byline_actions', (int) get_the_author_meta( 'ID' ) );
    ?>
	</div>
	<?php 
}

/**
 * SVG icons.
 *
 * @param string $name Icon name.
 * @param int    $size Size in pixels.
 * @return string
 */
function clevie_icon(  $name, $size = 16  ) {
    $paths = array(
        'up'      => '<path d="M12 4l8 9h-5v7H9v-7H4z"/>',
        'down'    => '<path d="M12 20l-8-9h5V4h6v7h5z"/>',
        'comment' => '<path d="M21 6a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3h2v4l5-4h5a3 3 0 003-3z"/>',
        'share'   => '<path d="M14 9V5l7 7-7 7v-4.1c-5 0-8.5 1.6-11 5.1 1-5 4-10 11-11z"/>',
        'search'  => '<path d="M10 4a6 6 0 104.47 10l4.26 4.27 1.42-1.42-4.27-4.26A6 6 0 0010 4zm0 2a4 4 0 110 8 4 4 0 010-8z"/>',
        'moon'    => '<path d="M12.3 3a9 9 0 108.7 11.3A7.5 7.5 0 0112.3 3z"/>',
        'sun'     => '<path d="M12 7a5 5 0 100 10 5 5 0 000-10zm0-6h0v3h0zm0 20v-3m9-7h3M0 12h3m14.7-6.7l2.1-2.1M4.2 19.8l2.1-2.1m11.4 0l2.1 2.1M4.2 4.2l2.1 2.1" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/>',
        'menu'    => '<path d="M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z"/>',
        'top'     => '<path d="M12 6l7 7-1.4 1.4L12 8.8l-5.6 5.6L5 13z"/>',
        'user'    => '<path d="M12 12a5 5 0 100-10 5 5 0 000 10zm0 2c-4.4 0-8 2.2-8 5v1h16v-1c0-2.8-3.6-5-8-5z"/>',
    );
    if ( !isset( $paths[$name] ) ) {
        return '';
    }
    return sprintf(
        '<svg class="cv-icon cv-icon-%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">%3$s</svg>',
        esc_attr( $name ),
        (int) $size,
        $paths[$name]
    );
}

/**
 * Render a comment.
 *
 * @param WP_Comment $comment Comment.
 * @param array      $args    Arguments.
 * @param int        $depth   Depth.
 */
function clevie_comment(  $comment, $args, $depth  ) {
    ?>
	<li id="comment-<?php 
    comment_ID();
    ?>" <?php 
    comment_class( 'cv-comment' );
    ?>>
		<article class="comment-body">
			<footer class="comment-meta">
				<span class="comment-author vcard">
					<?php 
    echo get_avatar( $comment, 24 );
    ?>
					<b class="fn"><?php 
    echo esc_html( clevie_user_prefix() . get_comment_author() );
    ?></b>
					<?php 
    /**
     * Room for actions beside the name of whoever wrote the comment, such as
     * blocking them.
     *
     * @param WP_Comment $comment Comment.
     */
    do_action( 'clevie_comment_byline_actions', $comment );
    ?>
				</span>
				<span>&middot;</span>
				<span>
					<?php 
    /* translators: %s: time since the comment was posted. */
    printf( esc_html__( '%s ago', 'clevie-social' ), esc_html( human_time_diff( get_comment_time( 'U' ), current_time( 'timestamp' ) ) ) );
    ?>
				</span>
				<?php 
    if ( '0' === $comment->comment_approved ) {
        ?>
					<em class="comment-awaiting-moderation"><?php 
        esc_html_e( 'Awaiting moderation.', 'clevie-social' );
        ?></em>
				<?php 
    }
    ?>
			</footer>
			<div class="comment-content"><?php 
    comment_text();
    ?></div>
			<div class="comment-actions">
				<?php 
    /**
     * Room for a vote element under a comment.
     *
     * @param WP_Comment $comment Comment.
     */
    do_action( 'clevie_comment_actions', $comment );
    ?>
			</div>
			<div class="reply">
				<?php 
    comment_reply_link( array_merge( $args, array(
        'add_below'  => 'comment',
        'depth'      => $depth,
        'max_depth'  => $args['max_depth'],
        'reply_text' => __( 'Reply', 'clevie-social' ),
    ) ) );
    ?>
			</div>
		</article>
	<?php 
    // wp_list_comments closes the </li> itself.
}

require_once get_template_directory() . '/inc/freemius.php';
require_once get_template_directory() . '/inc/layout.php';
require_once get_template_directory() . '/inc/typography.php';
require_once get_template_directory() . '/inc/post-options.php';
require_once get_template_directory() . '/inc/widgets.php';
require_once get_template_directory() . '/inc/integrations.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/magazine.php';
require_once get_template_directory() . '/inc/seo.php';
require_once get_template_directory() . '/inc/blocks.php';
// Clevie Community lives in the plugin directory, so the theme may point at it
// the ordinary way and this file stays in the free build. Recommending a plugin
// that is on wordpress.org is allowed; shipping one, or fetching one from
// elsewhere, is not.
require_once get_template_directory() . '/inc/companion.php';
require_once get_template_directory() . '/inc/settings-carry.php';
require_once get_template_directory() . '/inc/license-entry.php';
require_once get_template_directory() . '/inc/dark-logo.php';
require_once get_template_directory() . '/inc/load-more.php';